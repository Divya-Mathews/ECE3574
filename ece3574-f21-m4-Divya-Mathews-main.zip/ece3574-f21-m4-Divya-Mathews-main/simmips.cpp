#include "token.hpp"
#include "lexer.hpp"
#include "parser.hpp"
#include "virtualmachine.hpp"
#include <iostream>
#include <iomanip>
#include <fstream>
#include <sstream>
#include <limits>
#include <string>
#include <cstring>
#include <QApplication>
#include "virtual_machine_gui.hpp"


int main(int argc, char* argv[])
{
	if (argv[1] != NULL && argc > 1) {
		if (argc == 3) {
			if (std::string(argv[1]) == "--gui") {
				QApplication app(argc, argv);
				VirtualMachineGUI gui;
				QString filestring = QString::fromStdString(argv[2]);
				gui.load(filestring);
				gui.showNormal();
				return app.exec();
				return EXIT_SUCCESS;
			}
			else if (std::string(argv[2]) == "--gui") {
				QApplication app(argc, argv);
				VirtualMachineGUI gui;
				QString filestring = QString::fromStdString(argv[1]);
				gui.load(filestring);
				gui.showNormal();
				return app.exec();
				return EXIT_SUCCESS;
			}
			else {
				std::cerr << "Error: incorrect arguments";
				return EXIT_FAILURE;
			}
		}
		else if (argc == 2) {
			std::ifstream ins(argv[1], std::ifstream::in);
			//std::ifstream is(argv[1], std::ifstream::in);
			//std::cout << is.rdbuf();
			TokenList tl = tokenize(ins);
			if (!tl.empty() && tl.back().type() != ERROR) {
				bool parsed = parse(tl).first;
				VirtualMachine vm = parse(tl).second;

				if (parsed) {
					bool runOn = false;
					int progCounter = 0;
					std::string in;
					std::cout << "simmips> ";
					while (std::cin >> in) {
						//std::cout << "simmips>";
						std::string leading = "0x";
						if (in == "quit")
							break;
						else if (in == "status") {
							std::cout << "" << "\n";
						}
						//else if (in == "run") {
						//	runOn = true;
						//	while (progCounter < vm.totalCount) {
						//		vm.step(vm, progCounter);
						//	}
						//	progCounter = vm.pc;
						//	
						//}
						//else if (in == "break") {

						//}
						else if (in == "step") {
							if (progCounter < vm.totalCount) {
								vm = vm.step(vm, progCounter).second;
								progCounter = vm.pc;
								std::cout << leading << std::setw(8) << std::setfill('0') << std::hex << progCounter << "\n";
							}
							else {
								std::cerr << "Error: Program complete\r\n";
							}
						}
						else if (in == "print") {
							std::cin >> in;
							if (in.substr(0, 1) == "&") {
								int pos = in.find("x");
								std::string strVal = in.substr(pos + 1);
								int hexVal = 0;
								std::stringstream hexer;
								hexer << std::hex << strVal;
								hexer >> hexVal;
								int memVal = vm.memArray[hexVal];
								std::cout << leading << std::setw(2) << std::setfill('0') << std::hex << memVal << "\n";;
							}
							else if (in.substr(0, 1) == "$") {
								if (in == "$zero" || in == "$0") {
									int val = vm.getRegister("$zero");
									std::cout << leading << std::setw(8) << std::setfill('0') << std::hex << val << "\n";
								}
								else if (in == "$at" || in == "$1") {
									int val = vm.getRegister("$at");
									std::cout << leading << std::setw(8) << std::setfill('0') << std::hex << val << "\n";
								}
								else if (in == "$v0" || in == "$2") {
									int val = vm.getRegister("$v0");
									std::cout << leading << std::setw(8) << std::setfill('0') << std::hex << val << "\n";
								}
								else if (in == "$v1" || in == "$3") {
									int val = vm.getRegister("$v1");
									std::cout << leading << std::setw(8) << std::setfill('0') << std::hex << val << "\n";
								}
								else if (in == "$a0" || in == "$4") {
									int val = vm.getRegister("$a0");
									std::cout << leading << std::setw(8) << std::setfill('0') << std::hex << val << "\n";
								}
								else if (in == "$a1" || in == "$5") {
									int val = vm.getRegister("$a1");
									std::cout << leading << std::setw(8) << std::setfill('0') << std::hex << val << "\n";
								}
								else if (in == "$a2" || in == "$6") {
									int val = vm.getRegister("$a2");
									std::cout << leading << std::setw(8) << std::setfill('0') << std::hex << val << "\n";
								}
								else if (in == "$a3" || in == "$7") {
									int val = vm.getRegister("$a3");
									std::cout << leading << std::setw(8) << std::setfill('0') << std::hex << val << "\n";
								}
								else if (in == "$t0" || in == "$8") {
									int val = vm.getRegister("$t0");
									std::cout << leading << std::setw(8) << std::setfill('0') << std::hex << val << "\n";
								}
								else if (in == "$t1" || in == "$9") {
									int val = vm.getRegister("$t1");
									std::cout << leading << std::setw(8) << std::setfill('0') << std::hex << val << "\n";
								}
								else if (in == "$t2" || in == "$10") {
									int val = vm.getRegister("$t2");
									std::cout << leading << std::setw(8) << std::setfill('0') << std::hex << val << "\n";
								}
								else if (in == "$t3" || in == "$11") {
									int val = vm.getRegister("$t3");
									std::cout << leading << std::setw(8) << std::setfill('0') << std::hex << val << "\n";
								}
								else if (in == "$t4" || in == "$12") {
									int val = vm.getRegister("$t4");
									std::cout << leading << std::setw(8) << std::setfill('0') << std::hex << val << "\n";
								}
								else if (in == "$t5" || in == "$13") {
									int val = vm.getRegister("$t5");
									std::cout << leading << std::setw(8) << std::setfill('0') << std::hex << val << "\n";
								}
								else if (in == "$t6" || in == "$14") {
									int val = vm.getRegister("$t6");
									std::cout << leading << std::setw(8) << std::setfill('0') << std::hex << val << "\n";
								}
								else if (in == "$t7" || in == "$15") {
									int val = vm.getRegister("$t7");
									std::cout << leading << std::setw(8) << std::setfill('0') << std::hex << val << "\n";
								}
								else if (in == "$s0" || in == "$16") {
									int val = vm.getRegister("$s0");
									std::cout << leading << std::setw(8) << std::setfill('0') << std::hex << val << "\n";
								}
								else if (in == "$s1" || in == "$17") {
									int val = vm.getRegister("$s1");
									std::cout << leading << std::setw(8) << std::setfill('0') << std::hex << val << "\n";
								}
								else if (in == "$s2" || in == "$18") {
									int val = vm.getRegister("$s2");
									std::cout << leading << std::setw(8) << std::setfill('0') << std::hex << val << "\n";
								}
								else if (in == "$s3" || in == "$19") {
									int val = vm.getRegister("$s3");
									std::cout << leading << std::setw(8) << std::setfill('0') << std::hex << val << "\n";
								}
								else if (in == "$s4" || in == "$20") {
									int val = vm.getRegister("$s4");
									std::cout << leading << std::setw(8) << std::setfill('0') << std::hex << val << "\n";
								}
								else if (in == "$s5" || in == "$21") {
									int val = vm.getRegister("$s5");
									std::cout << leading << std::setw(8) << std::setfill('0') << std::hex << val << "\n";
								}
								else if (in == "$s6" || in == "$22") {
									int val = vm.getRegister("$s6");
									std::cout << leading << std::setw(8) << std::setfill('0') << std::hex << val << "\n";
								}
								else if (in == "$s7" || in == "$23") {
									int val = vm.getRegister("$s7");
									std::cout << leading << std::setw(8) << std::setfill('0') << std::hex << val << "\n";
								}
								else if (in == "$t8" || in == "$24") {
									int val = vm.getRegister("$t8");
									std::cout << leading << std::setw(8) << std::setfill('0') << std::hex << val << "\n";
								}
								else if (in == "$t9" || in == "$25") {
									int val = vm.getRegister("$t9");
									std::cout << leading << std::setw(8) << std::setfill('0') << std::hex << val << "\n";
								}
								else if (in == "$k0" || in == "$26") {
									int val = vm.getRegister("$k0");
									std::cout << leading << std::setw(8) << std::setfill('0') << std::hex << val << "\n";
								}
								else if (in == "$k1" || in == "$27") {
									int val = vm.getRegister("$k1");
									std::cout << leading << std::setw(8) << std::setfill('0') << std::hex << val << "\n";
								}
								else if (in == "$gp" || in == "$28") {
									int val = vm.getRegister("$gp");
									std::cout << leading << std::setw(8) << std::setfill('0') << std::hex << val << "\n";
								}
								else if (in == "$sp" || in == "$29") {
									int val = vm.getRegister("$sp");
									std::cout << leading << std::setw(8) << std::setfill('0') << std::hex << val << "\n";
								}
								else if (in == "$fp" || in == "$30") {
									int val = vm.getRegister("$fp");
									std::cout << leading << std::setw(8) << std::setfill('0') << std::hex << val << "\n";
								}
								else if (in == "$ra" || in == "$31") {
									int val = vm.getRegister("$ra");
									std::cout << leading << std::setw(8) << std::setfill('0') << std::hex << val << "\n";
								}
								else if (in == "$pc") {
									int val = vm.getRegister("$pc");
									std::cout << leading << std::setw(8) << std::setfill('0') << std::hex << val << "\n";
								}
								else if (in == "$hi") {
									int val = vm.getRegister("$hi");
									std::cout << leading << std::setw(8) << std::setfill('0') << std::hex << val << "\n";
								}
								else if (in == "$lo") {
									int val = vm.getRegister("$lo");
									std::cout << leading << std::setw(8) << std::setfill('0') << std::hex << val << "\n";
								}
								else {
									std::cerr << "Error: incorrect value" << "\n";
								}
							}
							else {
								std::cerr << "Error: incorrect command" << "\n";
							}
						}
						else {
							std::cerr << "Error: Enter a valid command\r\n";
						}

						std::cout << "simmips> ";
						//std::cin >> in;
					}
					return EXIT_SUCCESS;
				}
				else {
					std::cerr << "Error: parser failure\n";
					return EXIT_FAILURE;
				}
			}
			else {
				std::cerr << "Error: lexer failure\n";
				return EXIT_FAILURE;
			}
		}
		//return 0;
	}
	else {
		std::cerr << "Error:" << "line: " << argc << " file failure" << std::endl;
		return EXIT_FAILURE;
	}
	std::cerr << "Error" << std::endl;
	return EXIT_FAILURE;
}
