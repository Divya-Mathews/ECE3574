---
title: Milestone 1
---

# Introduction

The course project requires you to implement many of the design patterns and APIs discussed in class. The project for this semester is an instruction-level simulator of a common CPU instruction set architecture called [MIPS](https://en.wikipedia.org/wiki/MIPS_architecture).

MIPS is a [RISC](https://en.wikipedia.org/wiki/Reduced_instruction_set_computer) (reduced-instruction set computer) architecture adaptable to a wide-variety of applications, ranging from embedded systems (e.g. PIC32) and game consoles (e.g. PlayStation), to high-end servers (e.g. ARMv8). We will be simulating the first version, MIPS Release I, without co-processors. This CPU is ideally suited to our purposes since there are (relatively) few instructions with only three instruction formats and two addressing modes. It uses a 32-bit word size and has 32 general-purpose registers.

Our simulator, which we will call ``simmips``, will read a defined subset of MIPS assembly source code and simulate program execution, similar, but not identical to, [SPIM](http://spimsimulator.sourceforge.net/) and [MARS](http://courses.missouristate.edu/KenVollmar/mars/). The code and tests will be developed over the first part of the semester in milestones 1-3. We will then write a graphical debugger and visualization tool in milestones 4-5 during the last part of the semester.

The milestones will be used for grading and thus are motivation to not procrastinate. They correspond roughly to the schedule of material that we will be covering in class. Your progress will be tracked through a series of private git repositories on GitHub.

The goal of this first milestone is to develop the lexer for our simulator. This will allow you to get accustomed to the course workflow, gain experience reading specifications, and refresh your programming skills. You will write a lexer for MIPS assembly source files, producing a sequence of tokens.

This assignment requires very little C++ experience beyond basic data structures. If you struggle with this assignment you are ill-prepared for this course. This means you should devote additional time to it and seek advice from the TAs and myself, or as a last resort drop.

## Suggested Readings and Resources:

* Section 4 of "MIPS Assembly Language Programming using QtSpim", by Ed Jorgensen, 2016.
* [CMake Workflow on Windows](https://filebox.ece.vt.edu/~ECE2574/videos/Workflow2574-Windows/)
* [Wikipedia Background](https://en.wikipedia.org/wiki/Lexical_analysis)
* [A manual lexing tutorial](http://stlab.cc/legacy/how-to-write-a-simple-lexical-analyzer-or-parser.html)
* A [similar tutorial](http://llvm.org/docs/tutorial/LangImpl01.html)
* [A nice talk on lexing](https://www.youtube.com/watch?v=HxaD_trXwRE) from Rob Pike (not in C++ but clear)

# Basics of MIPS Assembly

The role of a compiler is to translate from a higher-level representation of a computation, called the source language, to a lower one, called the target language. Traditionally, when you are programming in a high-level language like C or C++, the target language is assembly. Individual files, or _modules_, are then passed through another compiler, called an assembler to produce object (machine) code. Multiple module object code is combined (usually with pre-compiled library code) by the linker to produce the final executable machine code. Modern compilers typically subsume high-level compilation and assembly into a single program, although they can emit intermediate languages. Some high-level languages (e.g. Java, C#, Lua, PLT scheme) compile to a portable intermediate language called bytecode, which is then compiled to machine code as needed (so-called just-in-time or JIT).

At each level of the compilation stage, the code moves from syntax that is more human understandable to less, while becoming more efficient for hardware execution. Assembly is the last language in this process that is symbolic enough that humans can interpret it without serious effort (one can decode and write/understand machine code, but it is a lot of work). Assembly language is expressed in plain text files called assembly source files. Like all languages it has a specific syntax, what constitutes a well-formed sequence of characters, and semantics, what the program does (it's side effects).

Our simulator will only simulate execution of a single module of code; thus, we will have no need for a linker. It will also not handle conditional assembly or macros.

It will be helpful to see an example first before diving into the details of the assembler source format in later milestones. So what follows is a simple program with some C-like translations.

```{.mips .numberLines}
# this is a comment, any characters after # up to newline are ignored

    .data # start the data section, where variables are declared

var1:   .byte 1      # char var1 = 1;
var2:   .half 65526  # short var2 = 65526;
var3:   .word 1      # int var3 = 1;
var4:   .word 2      # int var4 = 2;
var5:   .word 0      # int var5 = 0;

    .text # start the code section, a sequence of instructions
	
main: # compute var5 = var3 + var4;

        lw  $t0, var3 # load var3 into register t0
		lw  $t1, var4 # load var4 into register t1
		add $t3, $t0, $t1 # add the contents of t0 and t1, 
		                  # storing the result in t3
		sw  $t3, var5 # store register t3 contents into var5
```

Some initial things of note. Comments begin with the ``#`` character and are not semantically important to the execution of the program. The program contains several _directives_ to the compiler. These begin with a ``.`` character. The most prominent are ``.data`` and ``.text`` which control if the assembler is laying out or initializing memory, or processing computations as instructions. Also notable are _labels_, strings that end in the character ``:``. 

# A Tutorial on Lexing

This section is meant to show you the basic techniques of lexing. Once you have a basic idea what a lexer is and how to write one, you can apply these techniques to milestone 1. You can skip this section on your first reading of this assignment, but be sure to return to it before writing the code for milestone 1.

Lexing is the process of taking the raw input source, usually ASCII text, and converting it to a sequence of _tokens_. It is the first step in any parsing task as it separates the concerns of recognizing the combination of characters that are meaningful (the tokens) from their syntax, the organization of the tokens or _parsing_. Writing and testing the lexer as a stand-alone module is a good example of separation of concerns and abstraction.

Lexers are an example of the finite-state machine ( finite automata) design pattern/algorithm. This concept should be familiar to you as it is the core of digital hardware. Here we are using it as a code design tool. We can consider the input to be a sequence of characters, which we consider one at a time (in some cases you might need to look ahead or behind, but not in our case). The state-machine is in some initial state and the input is the first character. Depending on the initial state and the input the state machine transitions to a new (or the same ) state, possibly emitting outputs. This proceeds until there is no more input.

## Example: CSV files

Consider the task of reading a comma-separated-value, or CSV, file format. You likely have encountered these before in a programming course as they are an easy way to create a persistent sequence of structured row/columns (e.g. a file). For example, consider a plain text file with these contents: 

```
Last, First, email, user id
Wyatt, Chris, clwyatt@vt.edu, clwyatt
Kent, Clark, ckent@gmail.com, superman
Lane, Lois, llane@mail.com, lany

```

We can consider this file as a representing a sequence of tokens: 

```
STRING DELIMETER STRING DELIMETER STRING DELIMETER STRING EOL ... 
```

``DELIMETER`` is defined as a single character, in the above case ``,``, and ``EOL`` is defined as the line-feed character (ASCII code 10). ``STRING`` is defined as any sequence of characters not including ``DELIMETER`` or ``EOL``,  Given these definitions the job of the lexer is to convert the raw character stream from the file to a sequence of tokens with a type, ``STRING`` or ``DELIMETER``, and a value, usually a ``std::string``. We might define the appropriate data types in C++ as:

```cpp
enum TokenType {STRING, DELIMETER, EOL};

struct Token{
  TokenType type;
  std::string value;
  Token(TokenType t): type(t) {};
  Token(TokenType t, const std::string & v): type(t), value(v) {};
};

typedef std::list<Token> TokenSequence;
```

The lexer then takes in a stream of characters, e.g. from a file, and produces a token sequence. This function will read each character from the stream, toggling in between three states.

* if the input is a delimiter, then it transitions to a state where any previously accumulated string is added to the token list, the string is cleared, and a delimiter token is added to the list
* if the input is a newline, then it transitions to a state where any previously accumulated string is added to the token list, the string is cleared, and an end-of-line token is added to the list
* otherwise it adds the character to the accumulator string

Here is a function in C++ to perform the lexing.

```{.cpp .numberLines}
TokenSequence lexer(std::istream & input){

  TokenSequence tokens;

  char c;
  std::string temp;
  while(input.get(c)){
    
    switch(c){
    case ',':
      if(!temp.empty()){
    	tokens.emplace_back(STRING, temp);
	    temp.clear();
      }
      tokens.emplace_back(DELIMETER);
      break;
    case '\n':
      if(!temp.empty()){
	    tokens.emplace_back(STRING, temp);
	    temp.clear();
      }
      tokens.emplace_back(EOL);
      break;
    default:
      temp.push_back(c);
    }
  }

  return tokens;
}
```

Note that the lexer stores all values as strings, with no further processing. For example all whitespace between the delimiters is preserved. This is a consequence of the way the string token was defined (any character other than ',' and '\n'). In most lexing tasks whitespace such as spaces, tabs, and carriage-returns are treated as implicit string delimiters. Note also that there is no attempt to convert numbers, check the number of columns is the same as the first line, nor any other processing. Such tasks are generally left to the parser.

## Example: INI format

Consider another common format, often used for configuration files, the [INI](https://en.wikipedia.org/wiki/INI_file) format. Let's look at a simplified version.

```
; a comment
[section]

key1 = value ;another comment
key2 = "a value with space"
```

As far as the lexer is concerned the ini format differs from the csv format in just a few ways: comments must be stripped, delimited strings must be handled, and the token are different. Let's deal with these in order.

First, lets write a lexer that just strips the comments the returns the rest of the file contents as a string.

```{.cpp .numberLines}
// simple function to strip comments
std::string strip_comments(std::istream & input){

  char c;
  std::string result;
  while(input.get(c)){
    
    if(c == ';'){
      do{
  	    input.get(c);
      } while((c != '\n') && input.good());
    }
    else{
      result.push_back(c);
    }
  }

  return result;
}
```

Most of the work is done on lines 9-11, where the characters after the comment delimiter (``;`` in INI files) are just discarded. Note in particular this includes the newline at the end of a comment. Thus if we run the above example file through this function we get the string 

```
[section]

key1 = value key2 = "a value with space"
```

We can modify ``strip_comments``  to add a state to track when we are inside a pair of string delimiters (``"``). When in that state lexing other than comment processing is suspended.

```{.cpp}
// simple function to print all delimited strings
// ignore all comments
void print_strings(std::istream & input){

  bool instring = false;
  
  char c;
  std::string result;
  while(input.get(c)){
    
    if(c == ';' && !instring){
      do{
	input.get(c);
      } while((c != '\n') && input.good());
    }
    else if(c == '"' && !instring){
      instring = true;
    }
    else if(c == '"' && instring){
      instring = false;
      std::cout << result << "\n";
      result.clear();
    }
    else{
      if(instring){
	result.push_back(c);
      }
    }
  }
}
```

The state is tracked through a boolean variable ``instring``, which is toggled when encountering the ``"`` character. Notice this code moves from a switch-based to if-else decisions since we need more complex expressions. To test this works properly lets run the following through the function

```
; a comment "this should be ignored"
[section]

key1 = value ;another comment
key2 = "a value with space and a delimeter;"
```

which prints

```
a value with space and a delimeter;
```

Finally we can create our relevant token types ``OPEN_BRACKET``, ``CLOSE_BRACKET``, ``EQUAL``, and ``STRING``.

```{.cpp}
enum TokenType {OPEN_BRACKET, CLOSE_BRACKET, EQUAL, STRING};

struct Token{
	TokenType type;
	std::string value;
};

typedef std::list<Token> TokenSequence;
```

If the string delimiters were syntactically important (say we treated those strings differently somehow) then we might add an additional token for them. 

Now we can modify the ``print_strings`` and ``strip_comments`` into a complete lexer for our simplified INI files:

```{.cpp .numberLines}
TokenSequence lexer(std::istream & input){

  TokenSequence tokens;

  bool instring = false;
  
  char c;
  std::string temp;
  while(input.get(c)){

    if(c == ';' && !instring){
      do{
	input.get(c);
      } while((c != '\n') && input.good());
    }
    else if(c == '"' && !instring){
      instring = true;
    }
    else if(c == '"' && instring){
      instring = false;
      if(!temp.empty()){
	tokens.emplace_back(STRING, temp);
	temp.clear();
      }
    }
    else if((c =='[') && !instring){
      if(!temp.empty()){
	tokens.emplace_back(STRING, temp);
	temp.clear();
      }
      tokens.emplace_back(OPEN_BRACKET);
    }
    else if((c =='=') && !instring){
      if(!temp.empty()){
	tokens.emplace_back(STRING, temp);
	temp.clear();
      }
      tokens.emplace_back(EQUAL);
    }
    else if((c ==']') && !instring){
      if(!temp.empty()){
	tokens.emplace_back(STRING, temp);
	temp.clear();
      }
      tokens.emplace_back(CLOSE_BRACKET);
    }
    else if( std::isspace(c) && !instring ){
      if(!temp.empty()){
	tokens.emplace_back(STRING, temp);
	temp.clear();
      }
    }
    else{
      temp.push_back(c);
    }
  }  

  return tokens;
}
```

Note while this code is straightforward, it gets messy as the number of tokens increases. One could easily re-factor the common code into free functions to improve readability, and we will look at various techniques in lectures 15-16 to improve this further. The solution above also does no error checking, for example reaching a newline when ``instring`` is true would be considered an error. However these are relatively easy checks to add.

# Lexing the Assembly Source

MIPS assembly programs, like that above, are written in plain ASCII text. In the assembly file format there are several syntactically meaningful tokens:

* ``EOL`` (LF or ASCII code point 0x0a) indicates the end of a source line has been reached (no value)
* ``SEP`` (a comma or ASCII code point 0x2c) is the separator for lists (no value)
* ``OPEN_PAREN`` (an open parenthesis or ASCII code point 0x28) indicates the start of an indirect address (no value)
* ``CLOSE_PAREN`` (a close parenthesis or ASCII code point 0x29) indicates the end of an indirect address (no value)
* ``STRING_DELIM`` (double quote or ASCII code point 0x22) is used to wrap literal strings (no value)
* ``EQUAL`` (an equal sign or ASCII code point 0x3d) is used in a constant assignment (no value)
* ``STRING`` is any other white-space (ASCII code points 0x020, 0x0d, 0x09, 0x0b, or 0x0c) separated string (value is the string)

The job of the lexer is to convert the input text to a sequence of these tokens. It should discard any comments during this process by ignoring any input from the character ``#`` up to a newline. It should also record the line number from the file the token appeared on.

The interface is a C++ free function with the signature:

```{.cpp}
/* Function to convert an input text stream 
   into a sequence of tokens.
*/
TokenSequence lexer(std::istream &);
```

This function is declared in the file ``lexer.hpp`` and should be implemented in the file ``lexer.cpp``. A ``TokenSequence`` is a list of type Token

```{.cpp}
typedef std::list<Token> TokenList;
```

where a Token is a type, a line number where the token originated, and the string value

```{.cpp}
enum TokenType {
  EOL,
  SEP,
  EQUAL,
  OPEN_PAREN,
  CLOSE_PAREN,
  STRING_DELIM,
  STRING,
  ERROR
};

class Token {
public:
  // construct a token type on line with empty value
  Token(TokenType type, std::size_t line);

  // construct a token type on line  with value
  Token(TokenType type, std::size_t line, const std::string &value);

  // return the token type
  TokenType type() const;

  // return the token's originating source line
  std::size_t line() const;

  // return the token's value
  std::string value() const;
}
```

The ``Token`` and  ``TokenSequence`` types are defined and implemented in the module ``token.hpp``/``token.cpp``.

Example
---------

Consider the following contrived example of an assembly source file.

```
        .data
        LENGTH = 10
array:  .space LENGTH
str:    .asciiz "the (end)"
        .text
main:  lw $t0, array
       lw $t1, ($t0)
```

Would produce the following sequence of tokens, written as (type, value), where the line breaks are not significant.

```
(STRING,".data") (EOL,"") (STRING,"LENGTH") (EQUAL,"") (STRING,"10") (EOL,"") (STRING,"array:") (STRING,".space") (STRING,"LENGTH") (EOL,"") (STRING,"str:") (STRING,".asciiz") (STRING_DELIMETER,"") (STRING,"the (end)") (STRING_DELIMETER,"") (EOL,"") (STRING,".text") (EOL,"") (STRING,"main:") (STRING,"lw") (STRING,"$t0") (SEP,"") (STRING, "array") (EOL,"") (STRING,"lw") (STRING,"$t1") (SEP,"") (OPEN_PAREN,"") (STRING, "$t0") (CLOSE_PAREN,"") (EOL,"")
```

Note in particular that any text other than ASCII code 0xa in between pairs of ``"`` are treated literally (not as potential tokens).

The lexer should detect the following errors (only):

* A string must consist of matching ``"`` and cannot span multiple lines.
* A pair of ``(`` and ``)`` must match and cannot span multiple lines.
* Parenthesis should match in both number and kind or generate a lexer error. An example that would fail.

    ```
    This ) is some text(
    (this(is)
    some) more)
    ```
	
For example the following inputs would produce lexing errors.

```
.data
var: .ascii "this is
a string"
```

```
.text
    lw $t0, ($t1
	)
```

On the first error detected the last token in the returned sequence should have the type ``ERROR`` and the value should be an informative error message that starts with the string ``Error: ``. For example the token sequence resulting from the second error case above might be

```
(STRING,".text") (EOL,"") (STRING,"var:") (STRING,"lw") (STRING,"$t0") (SEP,"") (OPEN_PAREN,"") (ERROR,"Error: unmatched paren on line 2")
```

### Additional Specifications:

* ``EOL`` tokens are not emitted for blank lines (containing only whitespace and/or comments)
* The line number should reflect that in the original file, that is any newline should increase the line counter. We will be using this in later milestones for error reporting and in our debugger.
* in case of an empty string ``""`` three tokens should be emitted, ``STRING_DELIM``,``STRING``,``STRING_DELIM``, with the string value being an empty string

# Instructions

Accept the GitHub invitation above and then clone the git repository to your local machine. The initial git repository contains several files. The types for ``TokenSequence`` are defined for you in the header ``lexer.hpp``. Your task in this milestone is to implement the function ``tokenize`` in the file ``lexer.cpp``. You can define additional units of code (classes, helper functions) in ``lexer.cpp``, but do not change the provided type definitions, nor the ``tokenize`` function signature.

Unit tests for your function are provided in the file test_lexer.cpp using the Catch testing framework (see meeting 8). Do not modify them (other than to perhaps add temporary debugging output). The included CMakeLists.txt file sets up building these tests for you. Just configure the build, run the build, and then run the tests. You should use git to commit versions of your program source (only) as you go along, demonstrating good incremental programming technique.

Steps to build and run the tests in the reference environment (after vagrant ssh).

* To configure the build
  
    ```
    cmake /vagrant
    ```
  
* To run the build
 
    ```
    make
    ```
	
	or
	
	```
	cmake --build .
	```

* To run the unit tests
  
    ```
    make test
    ```
	
	or
	
	```
	cmake --build . --target test
	```
	
	The test output is placed in ``Testing/Temporary/LastTest.log. You can also just run the tests directly:
	
	```
	./unit_tests
	```
	
* To configure and run the build in strict mode (increased warnings, warnings become errors)
  
    ```
    cmake -DSTRICT=True /vagrant
	make clean; make
    ```

# Submission

To submit your assignment:

1. Tag the git commit that you wish to be considered for grading as "final".

	```
	git tag final
	```
2. Push this change to GitHub

	```
	git push origin final
	```
	
If you need to tag a different version of your code as final (before the due date) simply create and push a new tag appending a monotonically increasing number to final, e.g. final2, final3, etc.

Be sure you have committed all the changes you intend to. It is a good idea to re-clone your repository into a separate directory and double check it is what you intend to submit. **Failure to complete these steps by the due date will result in a failed submission.** 

# Grading 

There are 20 points allocated to this assignment constituting 6% of your course grade.

<table>
<colgroup>
<col style="width: 40%" />
<col style="width: 10%" />
</colgroup>
<tbody>
<tr>
<td style="text-align: left;">Code compiles in the grader/reference environment</td>
<td style="text-align: left;">4</td>
</tr>
<tr>
<td style="text-align: left;">Correctness</td>
<td style="text-align: left;">14</td>
</tr>
<tr>
<td style="text-align: left;">Code Quality</td>
<td style="text-align: left;">1</td>
</tr>
<tr>
<td style="text-align: left;">Good Development Practices</td>
<td style="text-align: left;">1</td>
</tr>
</tbody>
</table>

Note, if your code does not build in the reference environment you will receive **no points**. Correctness is determined by the proportion of instructor unit tests that pass. Code quality will be assessed in this assignment by ensuring your code compiles cleanly, with no warnings, using the strict mode specified above. Good development practices will be assessed by ensuring you have made more than 2 commits to your repository before submission.

Correctness can be [checked in the auto-grader](https://grader.ece.vt.edu) and is determined by the proportion of instructor tests that pass. The auto-grader uses the exact same environment as the reference so if your code compiles there, it should in the auto-grader as well (but check anyway!). You are rate-limited to only two submissions every two hours to the auto-grader so as to prevent you from using it as your development environment and encourage proper debugging skills.
