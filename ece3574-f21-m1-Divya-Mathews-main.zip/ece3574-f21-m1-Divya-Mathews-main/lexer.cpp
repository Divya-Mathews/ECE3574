#include "lexer.hpp"
#include <istream>
#include <iostream>
// implement the tokenize function here
// currently it just always returns an empty TokenList
TokenList tokenize(std::istream & ins){
	TokenList tl;
	bool instring = false;
	//bool inparen = false;
	//bool closeparen = false;

	std::size_t openCounter = 0, closeCounter = 0;

	char c = '0';
	std::string temp;
	std::size_t lineCount = 1;
	//std::size_t currSize = tl.size();

	while (ins.get(c)) {
		// for the # comment symbol
		if (c == '"' && !instring) {
			instring = true;
			tl.emplace_back(STRING_DELIM, lineCount);
		}
		else if (c == '"' && instring) {
			instring = false;
				tl.emplace_back(STRING, lineCount, temp);
				temp.clear();

			tl.emplace_back(STRING_DELIM, lineCount);
		}
		else if (c == '(' && !instring) {
			openCounter++;
			if (!temp.empty()) {
				tl.emplace_back(STRING, lineCount, temp);
				temp.clear();
			}
			tl.emplace_back(OPEN_PAREN, lineCount);
		}
		else if (c == ')' && !instring) {
			closeCounter++;
			if (!temp.empty()) {
				tl.emplace_back(STRING, lineCount, temp);
				temp.clear();
			}
			tl.emplace_back(CLOSE_PAREN, lineCount);
		}
		else if ((c == '=') && !instring) {
			if (!temp.empty()) {
				tl.emplace_back(STRING, lineCount, temp);
				temp.clear();
			}
			tl.emplace_back(EQUAL, lineCount);
		}
		else if (c == '\n') { // && !instring) {
			if ((openCounter != closeCounter) || instring) {
				tl.clear();
				tl.emplace_back(ERROR, lineCount, "Error: ending delimiter not found on line");
				return tl;
			}
			else if (!temp.empty()){
				tl.emplace_back(STRING, lineCount, temp);
				temp.clear();
				tl.emplace_back(EOL, lineCount);
			}
			else if (!tl.empty())
				tl.emplace_back(EOL, lineCount);
			lineCount++;
		}
		else if (c == ',' && !instring) {
			if (!temp.empty()) {
				tl.emplace_back(STRING, lineCount, temp);
				temp.clear();
			}
			tl.emplace_back(SEP, lineCount);
		}
		else if (std::isspace(c) && !instring) {
			if (!temp.empty()) {
				tl.emplace_back(STRING, lineCount, temp);
				temp.clear();
			}
		}
		else {
			temp.push_back(c);
		}
		//currSize = tl.size();
	}

	if (!temp.empty()) {
		//instring = false;
		tl.emplace_back(STRING, lineCount, temp);
		tl.emplace_back(EOL, lineCount);

	}

  return tl; 
}
