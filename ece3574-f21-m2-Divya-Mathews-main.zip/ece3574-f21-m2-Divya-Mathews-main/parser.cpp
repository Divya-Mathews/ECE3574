#include "parser.hpp"
#include <cstring>
// implement the parser here

bool parse(const TokenList& tokens) {

	//return 0;
	auto it = tokens.begin();
	StateType state = START;
	while ((it != tokens.end())) {
		switch (state) {
		case START:
			if (isComment(it->value())) state = PRE_DATA_COMMENT;
			else if (it->value() == ".data") state = DATA;
			else if (it->value() == ".text") state = TEXT;
			else if (it->type() == EOL) state = START;
			else state = ERROR_P;
			++it;
			break;
		case DATA:
			if (isComment(it->value())) state = DATA_COMMENT;
			else if (it->value() == ".text") state = TEXT;
			else if (isLabel(it->value())) state = LABEL;
			else if (isConstantStr(it->value())) state = CONSTANT_STR;
			else if (isIntLayout(it->value())) state = INT_LAYOUT;
			else if (isStrLayout(it->value())) state = STR_LAYOUT1;
			else if (it->type() == EOL) state = DATA;
			else state = ERROR_P;
			++it;
			break;
		case PRE_DATA_COMMENT:
			if (it->type() == EOL) state = START;
			else state = PRE_DATA_COMMENT;
			++it;
			break;
		case DATA_COMMENT:
			if (it->type() == EOL) state = DATA;
			else state = DATA_COMMENT;
			++it;
			break;
		case CONSTANT_STR:
			if (it->type() == EQUAL) state = CONSTANT;
			else state = ERROR_P;
			++it;
			break;
		case CONSTANT:
			if (isInteger(it->value())) state = EOL_DATA;
			else state = ERROR_P;
			++it;
			break;
		case LABEL:
			if (it->type() == EOL) state = DATA;
			else if (isIntLayout(it->value())) state = INT_LAYOUT;
			else if (isStrLayout(it->value())) state = STR_LAYOUT1;
			else state = ERROR_P;
			++it;
			break;
		case INT_LAYOUT:
			if (isInteger(it->value()) || isConstantStr(it->value())) state = COMMA;	// or is a constant alpha-dig string, does not check if previously used
			else state = ERROR_P;
			++it;
			break;
		case COMMA:
			if (it->type() == SEP) state = INT_LAYOUT;
			else if (it->type() == EOL) state = DATA;
			else if (isComment(it->value())) state = DATA_COMMENT;
			else state = ERROR_P;
			++it;
			break;
		case STR_LAYOUT1:
			if (it->type() == STRING_DELIM) state = STR_LAYOUT2;
			else state = ERROR_P;
			++it;
			break;
		case STR_LAYOUT2:
			if (it->type() == STRING) state = STR_LAYOUT3;
			else state = ERROR_P;
			it++;
			break;
		case STR_LAYOUT3:
			if (it->type() == STRING_DELIM) state = EOL_DATA;
			else state = ERROR_P;
			it++;
			break;
		case EOL_DATA:
			if (isComment(it->value())) state = DATA_COMMENT;
			else if (it->type() == EOL) state = DATA;
			else state = ERROR_P;
			++it;
			break;

		case TEXT:										//beginning of text section
			if (isComment(it->value())) state = TEXT_COMMENT;
			else if (isLabel(it->value())) state = TEXT;
			else if (it->value() == "nop") state = EOL_TEXT;
			else if (it->value() == "j") state = JUMP;
			else if (it->value() == "li") state = LI_1;
			else if (it->value() == "not") state = NOT_1;
			else if (it->value() == "div" || it->value() == "divu") state = DIV_1;
			else if (isRR(it->value())) state = R_R1;
			else if (isRM(it->value())) state = R_M1;
			else if (isRRS(it->value())) state = R_R_S1;
			else if (isR(it->value())) state = R;
			else if (isRSL(it->value())) state = R_S_L1;
			else if (it->type() == EOL) state = TEXT;
			else state = ERROR_P;
			++it;
			break;
		case TEXT_COMMENT:
			if (it->type() == EOL) state = TEXT;
			else state = TEXT_COMMENT; 
			it++; 
			break;
		case JUMP:
			if (isConstantStr(it->value())) state = EOL_TEXT;
			else state = ERROR_P;
			it++;
			break;
		case LI_1:
			if (isRegister(it->value())) state = LI_2;
			else state = ERROR_P;
			it++;
			break;
		case LI_2:
			if (it->type() == SEP) state = LI_3;
			else state = ERROR_P;
			it++;
			break;
		case LI_3:
			if (isImmediate(it->value())) state = EOL_TEXT;
			else state = ERROR_P;
			it++;
			break;
		case NOT_1:
			if (isRegister(it->value())) state = NOT_2;
			else state = ERROR_P;
			it++;
			break;
		case NOT_2:
			if (it->type() == SEP) state = NOT_3;
			else state = ERROR_P;
			it++;
			break;
		case NOT_3:
			if (isSource(it->value())) state = EOL_TEXT;
			else state = ERROR_P;
			it++;
			break;
		case DIV_1:
			if (isRegister(it->value())) state = DIV_2;
			else state = ERROR_P;
			it++;
			break;
		case DIV_2:
			if (it->type() == SEP) state = DIV_3;
			else state = ERROR_P;
			it++;
			break;
		case DIV_3:
			if (isRegister(it->value())) state = DIV_4;
			else state = ERROR_P;
			it++;
			break;
		case DIV_4:
			if (it->type() == SEP) state = DIV_5;
			else if (it->type() == EOL) state = TEXT;
			else if (isComment(it->value())) state = TEXT_COMMENT;
			else state = ERROR_P;
			it++;
			break;
		case DIV_5:
			if (isSource(it->value())) state = EOL_TEXT;
			else state = ERROR_P;
			it++;
			break;
		case R_R1:
			if (isRegister(it->value())) state = R_R2;
			else state = ERROR_P;
			it++;
			break;
		case R_R2:
			if (it->type() == SEP) state = R_R3;
			else state = ERROR_P;
			it++;
			break;
		case R_R3:
			if (isRegister(it->value())) state = EOL_TEXT;
			else state = ERROR_P;
			it++;
			break;
		case R_M1:
			if (isRegister(it->value())) state = R_M2;
			else state = ERROR_P;
			it++;
			break;
		case R_M2:
			if (it->type() == SEP) state = R_M3;
			else state = ERROR_P;
			it++;
			break;
		case R_M3:
			if (isConstantStr(it->value()) || isRegister(it->value())) state = EOL_TEXT;
			else if (isInteger(it->value())) state = R_M3_1;
			else if (it->type() == OPEN_PAREN) state = R_M4;
			else state = ERROR_P;
			it++;
			break;
		case R_M3_1:
			if (it->type() == OPEN_PAREN) state = R_M4;
			else state = ERROR_P;
			it++;
			break;
		case R_M4:
			if (isRegister(it->value())) state = R_M5;
			else state = ERROR_P;
			it++;
			break;
		case R_M5:
			if (it->type() == CLOSE_PAREN) state = EOL_TEXT;
			else state = ERROR_P;
			it++;
			break;
		case R_R_S1:
			if (isRegister(it->value())) state = R_R_S2;
			else state = ERROR_P;
			it++;
			break;
		case R_R_S2:
			if (it->type() == SEP) state = R_R_S3;
			else state = ERROR_P;
			it++;
			break;
		case R_R_S3:
			if (isRegister(it->value())) state = R_R_S4;
			else state = ERROR_P;
			it++;
			break;
		case R_R_S4:
			if (it->type() == SEP) state = R_R_S5;
			else state = ERROR_P;
			it++;
			break;
		case R_R_S5:
			if (isSource(it->value())) state = EOL_TEXT;
			else state = ERROR_P;
			it++;
			break;
		case R:
			if (isRegister(it->value())) state = EOL_TEXT;
			else state = ERROR_P;
			it++;
			break;
		case R_S_L1:
			if (isRegister(it->value())) state = R_S_L2;
			else state = ERROR_P;
			it++;
			break;
		case R_S_L2:
			if (it->type() == SEP) state = R_S_L3;
			else state = ERROR_P;
			it++;
			break;
		case R_S_L3:
			if (isSource(it->value())) state = R_S_L4;
			else state = ERROR_P;
			it++;
			break;
		case R_S_L4:
			if (it->type() == SEP) state = R_S_L5;
			else state = ERROR_P;
			it++;
			break;
		case R_S_L5:
			if (isConstantStr(it->value())) state = EOL_TEXT;
			else state = ERROR_P;
			it++;
			break;
		case EOL_TEXT:
			if (isComment(it->value())) state = EOL_TEXT;
			else if (it->type() == EOL) state = TEXT;
			else state = ERROR_P;
			it++;
			break;
		case ERROR_P:
			return false;
		default:
			state = ERROR_P;
			break;
		}
	}
	return true;
}


bool isConstantStr(std::string value) {
	bool is = false;
	if (isAlpha(value[0])) {
		for (std::size_t i = 1; i < value.length(); i++) {
			if (!isAlpha(value[i]) && !isdigit(value[i]))
				return false;
		}
		is = true;
	}
	return is;
}

bool isLabel(std::string value) {
	bool is = false;
	if (isAlpha(value[0]) && (value[value.length() - 1] == ':')) {
		for (std::size_t i = 1; i < value.length() - 1; i++) {
			if (!isAlpha(value[i]) && !isdigit(value[i]))
				return false;
		}
		is = true;
	}
	return is;
}

bool isInteger(std::string value) {
	bool is = false;
	if (value[0] == '-' || value[0] == '+' || isdigit(value[0])) {
		for (std::size_t i = 1; i < value.length(); i++) {
			if (!isdigit(value[i]))
				return false;
		}
		is = true;
	}
	return is;
}

bool isComment(std::string value) {
	if (value[0] == '#')
		return true;
	else return false;
}

bool isAlpha(char c) {
	return ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == '_');
}


bool isStrLayout(std::string value) {
	return (value == ".ascii" || value == ".asciiz");
}

bool isIntLayout(std::string value) {
	return (value == ".word" || value == ".half" || value == ".byte" || value == ".space");
}

bool isRR(std::string value) {
	return (value == "move" || value == "mult" || value == "multu" || value == "abs" || value == "neg" || value == "negu");
}

bool isR(std::string value) {
	return (value == "mfhi" || value == "mflo" || value == "mthi" || value == "mtlo");
}

bool isRRS(std::string value) {
	return (value == "add" || value == "addu" || value == "sub" || value == "subu" || value == "mul" || value == "mulo" || value == "mulou" || value == "rem" || value == "remu"
		|| value == "and" || value == "nor" || value == "or" || value == "xor");
}

bool isRSL(std::string value) {
	return (value == "beq" || value == "bne" || value == "blt" || value == "ble" || value == "bgt" || value == "bge");
}

bool isRM(std::string value) {
	return (value == "lw" || value == "lh" || value == "lb" || value == "la" || value == "sw" || value == "sh" || value == "sb");
}

bool isRegister(std::string value) {
	bool is = false;
	if (value[0] == '$') {
		for (std::size_t i = 1; i < value.length(); i++) {
			if (!isAlpha(value[i]) && !isdigit(value[i]))
				return false;
		}
		is = true;
	}
	return is;
}

bool isImmediate(std::string value) {
	return (isInteger(value) || isConstantStr(value));
}

bool isSource(std::string value) {
	return (isRegister(value) || isImmediate(value));
}
