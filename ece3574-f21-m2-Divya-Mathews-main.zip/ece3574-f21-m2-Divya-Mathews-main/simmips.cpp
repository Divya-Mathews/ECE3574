#include "token.hpp"
#include "lexer.hpp"
#include "parser.hpp"
#include <iostream>
#include <fstream>

// implement entry point for simmips here

int main(int argc, char* argv[])
{
	if (argv[1] != NULL && argc > 1) {
		std::ifstream ins(argv[1], std::ifstream::in);
		TokenList tl = tokenize(ins);
		if (tl.back().type() != ERROR) {
			if (parse(tl) == true) {
				return EXIT_SUCCESS;
				//return 0;
			}
			else {
				std::cerr << "Error: parser failure" << std::endl;
				return EXIT_FAILURE;
			}
		}
		else {
			std::cerr << "Error: lexer failure" << std::endl;
			return EXIT_FAILURE;
		}
	}
	else {
		std::cerr << "Error:" << "line:" << argc << "file failure" << std::endl;
		return EXIT_FAILURE;
	}

	//return 0;
}
