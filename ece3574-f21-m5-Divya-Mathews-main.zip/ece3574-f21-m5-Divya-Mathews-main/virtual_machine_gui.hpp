#ifndef VIRTUAL_MACHINE_GUI_HPP
#define VIRTUAL_MACHINE_GUI_HPP

#include <QString>
#include <QWidget>
#include <QPlainTextEdit>
#include <QTableView>
#include <QLineEdit>
#include <QPushButton>
#include <QStandardItemModel>
#include "virtualmachine.hpp"
#include <string>

// TODO define the GUI class

class VirtualMachineGUI: public QWidget{
	Q_OBJECT
public:
	VirtualMachineGUI(QWidget* parent = nullptr);
	~VirtualMachineGUI();

	void highlightCurrentInstruction();
	void load(QString filename);

	VirtualMachine vm;

	QPlainTextEdit* text;
	QTableView* registers;
	QTableView* memory;
	QLineEdit* status;
	QPushButton* step;
	QPushButton* run;
	QPushButton* breakbutton;
	QStandardItemModel* regModel;
	QStandardItemModel* memModel;
	std::string buffstr = "";
	int progCounter = 0;
	std::vector<std::string> programVector = std::vector<std::string>(10);
	void runResult();
	

public slots:
	void handleButtonPushStep();
	void handleButtonPushRun();
	void handleButtonPushBreak();
};


#endif
