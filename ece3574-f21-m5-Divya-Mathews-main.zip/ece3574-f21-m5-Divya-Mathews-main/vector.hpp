#ifndef VECTOR_HPP
#define VECTOR_HPP
#include <vector>
#include <mutex>
#include <thread>
#include <iostream>

template<typename T>
class ThreadSafeVector {
public:
	void clear() {
		std::unique_lock<std::mutex> lock(mtx);
		vec.clear();
		lock.unlock();
	}
	int length() {
		std::unique_lock<std::mutex> lock(mtx);
		return vec.size();
	}
	void push_back(const T& value) {
		std::unique_lock<std::mutex> lock(mtx);
		vec.push_back(value);
		lock.unlock();
	}
	void set(int index, T& value) {
		std::unique_lock<std::mutex> lock(mtx);
		vec[index] = value;
		lock.unlock();
	}
	T get(int index){
		std::unique_lock<std::mutex> lock(mtx);
		return vec[index];
		lock.unlock();
	}
private:
	std::vector<T> vec;
	mutable std::mutex mtx;
};



#endif