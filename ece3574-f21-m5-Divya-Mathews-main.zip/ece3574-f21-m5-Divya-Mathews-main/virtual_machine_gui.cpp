#include "virtual_machine_gui.hpp"
#include "virtualmachine.hpp"
#include "lexer.hpp"
#include "parser.hpp"
#include <string>
#include <iostream>
#include <fstream>
#include <parser.hpp>
#include <QLayout>
#include <QTableView>
#include <QStandardItemModel>
#include <QHeaderView>
#include <QLabel>
#include <QObject>
#include <iomanip>
#include <sstream>
#include <algorithm>
#include<vector.hpp>
//#include <virtualmachine.hpp>
//ThreadSafeVector<std::string> thvec;

// TODO implement the GUI class
VirtualMachineGUI::VirtualMachineGUI(QWidget* parent) :QWidget(parent) {
	
	//set up subwidgets

	// text space
	text = new QPlainTextEdit();
	text->setObjectName("text");
	//highlightCurrentInstruction();

	// registers table
	registers = new QTableView();
	registers->setObjectName("registers");
	registers->verticalHeader()->hide();


	// memory table
	memory = new QTableView();
	memory->setObjectName("memory");
	memory->verticalHeader()->hide();

	// status bar
	status = new QLineEdit();
	status->setObjectName("status");
	status->setReadOnly(true);

	// step button
	step = new QPushButton("step", this);
	step->setObjectName("step");
	connect(step, SIGNAL(released()), this, SLOT(handleButtonPushStep()));

	// run button
	run = new QPushButton("run", this);
	run->setObjectName("run");
	connect(step, SIGNAL(released()), this, SLOT(handleButtonPushRun()));

	// break button
	breakbutton = new QPushButton("break", this);
	breakbutton->setObjectName("break");
	connect(step, SIGNAL(released()), this, SLOT(handleButtonPushBreak()));
	breakbutton->setEnabled(false);

	{//registers fill
		QStringList regHeaders;
		regHeaders << "Number" << "Alias" << "Value (Hex)";
		regModel = new QStandardItemModel(34, 3);
		regModel->setHorizontalHeaderLabels(regHeaders);
		registers->setModel(regModel);
		QStringList regNumbers{ "$0", "$1", "$2", "$3", "$4", "$5", "$6", "$7", "$8", "$9", "$10", "$11", "$12", "$13", "$14", "$15", "$16",
		"$17", "$18", "$19", "$20", "$21", "$22", "$23", "$24", "$25", "$26", "$27", "$28", "$29", "$30", "$31" };
		for (int i = 0; i < regNumbers.size(); i++) {
			QStandardItem* item = new QStandardItem(regNumbers[i]);
			regModel->setItem(i + 3, 0, item);
		}

		QStringList regAliases{ "$pc", "$hi", "$lo", "$zero", "$at", "$v0", "$v1", "$a0", "$a1", "$a2", "$a3", "$t0", "$t1", "$t2", "$t3",
		"$t4", "$t5", "$t6", "$t7", "$s0", "$s1", "$s2", "$s3", "$s4", "$s5", "$s6", "$s7", "$t8", "$t9", "$k0", "$k1", "$gp", "$sp", "$fp", "$ra" };

		for (int i = 0; i < regAliases.size(); i++) {
			QStandardItem* item = new QStandardItem(regAliases[i]);
			regModel->setItem(i, 1, item);

			std::stringstream values;
			values << "0x" << std::setw(8) << std::setfill('0') << std::hex << vm.getRegister(regAliases[i].toStdString());
			std::string val(values.str());
			QString qval = QString::fromStdString(val);
			QStandardItem* itemval = new QStandardItem(qval);
			regModel->setItem(i, 2, itemval);
		}
	}

	{//memory fill
		QStringList memHeaders;
		memHeaders << "Address (Hex)" << "Value (Hex)";
		memModel = new QStandardItemModel(1024, 2);
		memModel->setHorizontalHeaderLabels(memHeaders);
		memory->setModel(memModel);
		for (int i = 0; i < 1024; i++) {
			std::stringstream addr, values;
			addr << "0x" << std::setw(8) << std::setfill('0') << std::hex << i;
			std::string addrs(addr.str());
			QString qval = QString::fromStdString(addrs);
			QStandardItem* item = new QStandardItem(qval);
			memModel->setItem(i, 0, item);

			values << "0x" << std::setw(8) << std::setfill('0') << std::hex << 0 << "\n";
			std::string vals(values.str());
			QString qvals = QString::fromStdString(vals);
			QStandardItem* itemval = new QStandardItem(qvals);
			memModel->setItem(i, 1, itemval);

		}
	}

	QHBoxLayout* textRegMemLayout = new QHBoxLayout;
	QHBoxLayout* statusLayout = new QHBoxLayout;
	QHBoxLayout* steprunbreakLayout = new QHBoxLayout;
	textRegMemLayout->addWidget(text);
	textRegMemLayout->addWidget(registers);
	textRegMemLayout->addWidget(memory);
	statusLayout->addWidget(status);
	steprunbreakLayout->addWidget(step);
	steprunbreakLayout->addWidget(run);
	steprunbreakLayout->addWidget(breakbutton);

	QVBoxLayout* overallLayout = new QVBoxLayout;
	overallLayout->addLayout(textRegMemLayout);
	overallLayout->addLayout(statusLayout);
	overallLayout->addLayout(steprunbreakLayout);

	setLayout(overallLayout);
}

VirtualMachineGUI::~VirtualMachineGUI() {

}

void VirtualMachineGUI::handleButtonPushStep() {
	if ((std::size_t)progCounter < vm.program.size()) {
		vm = vm.step(vm, progCounter).second;
		progCounter = vm.pc;
		QStringList regAliases{ "$pc", "$hi", "$lo", "$zero", "$at", "$v0", "$v1", "$a0", "$a1", "$a2", "$a3", "$t0", "$t1", "$t2", "$t3",
		"$t4", "$t5", "$t6", "$t7", "$s0", "$s1", "$s2", "$s3", "$s4", "$s5", "$s6", "$s7", "$t8", "$t9", "$k0", "$k1", "$gp", "$sp", "$fp", "$ra" };
		for (int i = 0; i < 34; i++) {
			std::stringstream values;
			values << "0x" << std::setw(8) << std::setfill('0') << std::hex << vm.getRegister(regAliases[i].toStdString());
			std::string val(values.str());
			QString qval = QString::fromStdString(val);
			QStandardItem* itemval = new QStandardItem(qval);
			regModel->setItem(i, 2, itemval);
		}
		for (int i = 0; i < 1024; i++) {
			std::stringstream values;
			int memVal = vm.memArray[i];
			values << "0x" << std::setw(2) << std::setfill('0') << std::hex << memVal;
			std::string vals(values.str());
			QString qvals = QString::fromStdString(vals);
			QStandardItem* itemval = new QStandardItem(qvals);
			memModel->setItem(i, 1, itemval);
		}
		highlightCurrentInstruction();
	}
	else {
		status->setText("Error: Program complete");
		step->setEnabled(false);
	}
}

void VirtualMachineGUI::handleButtonPushRun() {
	//if ((std::size_t)vm.pc < vm.program.size()) {
	//	run->setEnabled(false);
	//	step->setEnabled(false);
	//	breakbutton->setEnabled(true);
	//	std::thread t(&VirtualMachineGUI::runResult, this);
	//	t.detach();
	//}
	//else
	//	status->setText("Error: Program complete");
}

void VirtualMachineGUI::runResult() {
	//while ((std::size_t)progCounter < vm.program.size()) {
	//	handleButtonPushStep();
	//	if (thvec.length() != 0) {
	//		thvec.clear();
	//		break;
	//	}
	//}
}

void VirtualMachineGUI::handleButtonPushBreak() {
	//if (run->isEnabled()) {
		/*run->setEnabled(true);
		step->setEnabled(true);
		breakbutton->setEnabled(false);
		thvec.push_back("break");
		QStringList regAliases{ "$pc", "$hi", "$lo", "$zero", "$at", "$v0", "$v1", "$a0", "$a1", "$a2", "$a3", "$t0", "$t1", "$t2", "$t3",
		"$t4", "$t5", "$t6", "$t7", "$s0", "$s1", "$s2", "$s3", "$s4", "$s5", "$s6", "$s7", "$t8", "$t9", "$k0", "$k1", "$gp", "$sp", "$fp", "$ra" };
		for (int i = 0; i < 34; i++) {
			std::stringstream values;
			values << "0x" << std::setw(8) << std::setfill('0') << std::hex << vm.getRegister(regAliases[i].toStdString());
			std::string val(values.str());
			QString qval = QString::fromStdString(val);
			QStandardItem* itemval = new QStandardItem(qval);
			regModel->setItem(i, 2, itemval);
		}
		for (int i = 0; i < 1024; i++) {
			std::stringstream values;
			int memVal = vm.memArray[i];
			values << "0x" << std::setw(2) << std::setfill('0') << std::hex << memVal;
			std::string vals(values.str());
			QString qvals = QString::fromStdString(vals);
			QStandardItem* itemval = new QStandardItem(qvals);
			memModel->setItem(i, 1, itemval);
		}
		highlightCurrentInstruction();*/
	//}
}

void VirtualMachineGUI::highlightCurrentInstruction() {
	int line = progCounter + 1;
	std::string instruction = programVector[line];
	QString qInstruction = QString::fromStdString(instruction);
	text->find(qInstruction, QTextDocument::FindCaseSensitively);
}

void VirtualMachineGUI::load(QString filename) {
	std::ifstream file(filename.toStdString());
	std::ifstream filestream(filename.toStdString(), std::ifstream::in);
	if (file.good()) {
		status->setText("Ok");
		//in.open(fi);
		std::stringstream buffer;
		std::string line;
		buffer << file.rdbuf();
		buffstr = buffer.str();
		text->setPlainText(QString::fromStdString(buffstr));
		TokenList tl = tokenize(filestream);
		if (!tl.empty() && tl.back().type() != ERROR) {
			bool parsed = parse(tl).first;
			vm = parse(tl).second;
			if (parsed) {
				QStringList memHeaders;
				memHeaders << "Address (Hex)" << "Value (Hex)";
				memModel->setHorizontalHeaderLabels(memHeaders);
				memory->setModel(memModel);
				for (int i = 0; i < 1024; i++) {
					std::stringstream values;
					int memVal = vm.memArray[i];
					values << "0x" << std::setw(2) << std::setfill('0') << std::hex << memVal;
					std::string vals(values.str());
					QString qvals = QString::fromStdString(vals);
					QStandardItem* itemval = new QStandardItem(qvals);
					memModel->setItem(i, 1, itemval);
				}
				//QString firstInstr = QString::fromStdString(programVector[1]);
				//text->find(firstInstr, QTextDocument::FindCaseSensitively);
			}
			else {
				status->setText("Error: Parser error");
			}
		}
		else {
			status->setText("Error: Tokenizer error");
		}
	}
	else {
		status->setText("Error: File error");
	}
}
