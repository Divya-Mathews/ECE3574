#include "catch.hpp"
#include "token.hpp"
#include "lexer.hpp"
#include "parser.hpp"
#include <string>
#include <sstream>
#include <iostream>
#include <map>
#include "virtualmachine.hpp"

TEST_CASE("test helpers in vm", "[virtualmachine]") {
	// add word, half, or byte to memory
	{
		VirtualMachine vm;
		std::string val = "200";
		vm.addWHBToMemory(val, 4);
		REQUIRE(vm.memArray[0] == 200);
		vm.addWHBToMemory(val, 2);
		REQUIRE(vm.memArray[4] == 200);
		vm.addWHBToMemory(val, 1);
		REQUIRE(vm.memArray[6] == 200);
		REQUIRE_FALSE(vm.addWHBToMemory(val, 5));
		std::string val2 = "5";

		//replace memory word
		vm.replaceMemoryWord(val2, 0);
		REQUIRE(vm.memArray[0] == 5);
		REQUIRE(vm.memArray[1] == 0);
		vm.replaceMemoryWord(val2, 1);
		REQUIRE(vm.memArray[1] == 5);

		//add space to memory
		vm.addSpaceToMemory(3);
		vm.addWHBToMemory(val, 1);
		REQUIRE(vm.memArray[7] == 0);
		REQUIRE(vm.memArray[8] == 0);
		REQUIRE(vm.memArray[9] == 0);
		REQUIRE(vm.memArray[10] == 200);
	}
	{
		//add string to mem
		VirtualMachine vm;
		std::string val = "a";
		std::string type = ".ascii";
		vm.addStringToMemory(type, val);
		REQUIRE(vm.memArray[0] == int(val[0]));
	}
	{
		//constants
		VirtualMachine vm;
		std::string val = "val";
		std::string num = "5";
		vm.addConstant(val, num);
		REQUIRE(vm.getConstant(val) == 5);
		REQUIRE(vm.constantExists(val));
	}
	{
		//data labels
		VirtualMachine vm;
		std::string val = "label:";
		std::pair<std::string, int> pair("10", 0);
		vm.addDataLabel(val, pair);
		REQUIRE(vm.getDataLabel("label").first == "10");
		REQUIRE(vm.getDataLabel("label").second == 0);
		REQUIRE(vm.dataLabelExists(val));
	}
	{
		//text labels
		VirtualMachine vm;
		std::string val = "label:";
		int ptr = 2;
		vm.addTextLabel(val, ptr);
		REQUIRE(vm.getTextLabel("label") == 2);
		REQUIRE(vm.textLabelExists(val));
	}
	{
		VirtualMachine vm;
		std::string reg = "$t0";
		vm.setRegister(reg, 7);
		REQUIRE(vm.getRegister(reg) == 7);
	}
}

TEST_CASE("lw test", "[virtualmachine]") {
	{
		VirtualMachine vm;
		vm.setRegister("$t0", 7);
		Instruction it;
		it.opcode = "lw";
		it.oper1 = "$t1";
		it.oper2 = "$t0";
		vm.program.push_back(it);
		vm = vm.step(vm, 0).second;
		//REQUIRE(vm.getRegister("$t1") == 7);
	}
	{
		VirtualMachine vm;
		std::pair<std::string, int> pair("10", 0);
		vm.addDataLabel("n:", pair);
		Instruction i2;
		i2.opcode = "lw";
		i2.oper1 = "$t1";
		i2.oper2 = "n";
		vm.program.push_back(i2);
		vm = vm.step(vm, 0).second;
		REQUIRE(vm.getRegister("$t1") == 10);
	}
}

TEST_CASE("test li", "[virtualmachine]") {
	{
		VirtualMachine vm;
		Instruction it;
		it.opcode = "li";
		it.oper1 = "$t1";
		it.oper2 = "1";
		vm.program.push_back(it);
		vm = vm.step(vm, 0).second;
		REQUIRE(vm.getRegister("$t1") == 1);

	}
}

TEST_CASE("test mult", "[virtualmachine]") {
	{
		VirtualMachine vm;
		vm.setRegister("$t1", 4);
		Instruction it;
		it.opcode = "mult";
		it.oper1 = "$t1";
		it.oper2 = "$t1";
		vm.program.push_back(it);
		vm = vm.step(vm, 0).second;
		REQUIRE(vm.getRegister("$lo") == 16);
	}
}

TEST_CASE("test mflo", "[virtualmachine]") {
	{
		VirtualMachine vm;
		vm.setRegister("$lo", 16);
		Instruction it;
		it.opcode = "mflo";
		it.oper1 = "$t1";
		vm.program.push_back(it);
		vm = vm.step(vm, 0).second;
		REQUIRE(vm.getRegister("$t1") == 16);
	}
}

TEST_CASE("test hex function", "[virtualmachine]") {
	//std::string s = "20";
	//int decimal_value = stoi(s);
	//std::stringstream ss;
	//ss << std::hex << decimal_value; // int decimal_value
	//std::string res(ss.str());
	//int val = stoi(res);
	//std::cout << val;

}

TEST_CASE("test bitmask", "[virtualmachine]") {
	unsigned char memArray[32];
	std::string s = "20";
	long int decimal = stoi(s);
	memArray[3] = (int)((decimal >> 24) & 0xFF);
	memArray[2] = (int)((decimal >> 16) & 0xFF);
	memArray[1] = (int)((decimal >> 8) & 0XFF);
	memArray[0] = (int)((decimal & 0XFF));
	
	REQUIRE(memArray[0] == 20);

	std::string r = "-21";
	long int decimal_1 = stoi(r);
	memArray[7] = (int)((decimal_1 >> 24) & 0xFF);
	memArray[6] = (int)((decimal_1 >> 16) & 0xFF);
	memArray[5] = (int)((decimal_1 >> 8) & 0XFF);
	memArray[4] = (int)((decimal_1 & 0XFF));
	REQUIRE(memArray[4] == 235);

}

TEST_CASE("test memory adding", "[virtualmachine]") {
	VirtualMachine vm;
	REQUIRE(vm.addWHBToMemory("5", 1));
	REQUIRE(vm.memArray[0] == 5);
	REQUIRE(vm.addWHBToMemory("12", 4));
	REQUIRE(vm.memArray[1] == 12);
	REQUIRE(vm.memArray[2] == 0);
	//REQUIRE(vm.memArray[5] == NULL);
	REQUIRE(vm.addSpaceToMemory(2));
	REQUIRE(vm.memArray[5] == 0);
	REQUIRE(vm.addStringToMemory(".ascii", "test"));
	REQUIRE(vm.memArray[7] == int('t'));
	REQUIRE(vm.memArray[10] == int('t'));
	REQUIRE(vm.addStringToMemory(".asciiz", "test2"));
	REQUIRE(vm.memArray[11] == int('t'));
	REQUIRE(vm.memArray[15] == int('2'));
	REQUIRE(vm.memArray[16] == 0);
	//std::cout << vm.memArray[0];
}

TEST_CASE("test 01 passes", "[virtualmachine]") {
	std::string ins = R"(	
# a test for constants
	.data
	LENGTH = 1024
arr:	.space LENGTH
	
	.text)";
	std::istringstream iss(ins);
	TokenList t1 = tokenize(iss);
	REQUIRE(parse(t1).first);
	VirtualMachine vm = parse(t1).second;
	REQUIRE(parse(t1).second.memArray[1023] == 0);
	//int pc = 0;
	//while (pc < vm.pc) {
	//	vm.step(vm, pc);
	//}
	//REQUIRE(vm.get)
}

TEST_CASE("test 00 passes", "[virtualmachine]") {
	std::string ins = R"(	
# A test file of data declarations only
	.data
var1:	.word 1024             # int var1 = 1024

var2:	.half 12               # short var2 = 12
	
var3:	.byte 0                # char var3 = 0

var4:	.byte 1, 2, 3, 4, 5, 6, 7, 8  # var4 = {1,2,3,4,5,6,7,8}

var5:	.space 512             # reserve 512 bytes

var6:	.ascii "hello"

var7:	.asciiz "goodbye"

	.text)";
	std::istringstream iss(ins);
	TokenList t1 = tokenize(iss);
	REQUIRE(parse(t1).first);
	
}

TEST_CASE("test 00 fails", "[virtualmachine]") {
	std::string ins = R"(	
# A test file of data declarations only
	.data
var1:	.word 1024             # int var1 = 1024

var2:	.half 12               # short var2 = 12
	
var3:	.byte 0                # char var3 = 0

var4:	.byte 1, 2, 3, 4, 5, 6, 7,   # PARSE ERROR

var5:	.space 512             # reserve 512 bytes

var6:	.ascii "hello"

var7:	.asciiz "goodbye"

	.text)";
	std::istringstream iss(ins);
	TokenList t1 = tokenize(iss);
	REQUIRE_FALSE(parse(t1).first);
}

TEST_CASE("test 05 passes text", "[virtualmachine]") {
	std::string ins = R"(        
.data
VALUE = -1
var:    .word 1
        .text
main:
        lw $t0, var
        add $t1, $t0, VALUE
        add $t2, $t1, $t0)";
	std::istringstream iss(ins);
	TokenList t1 = tokenize(iss);
	REQUIRE(parse(t1).first);
}

TEST_CASE("test 01 should pass", "[virtualmachine]") {
	std::string ins = R"(       
        .data
r1:     .space 4
r2:     .space 12
r3:     .space 4
var:    .word 7

        .text
main:
        la $t0, r2
     	lw $t1, var

	sw $t1, 0
	sw $t1, $t0
	sw $t1, 4($t0)
	sw $t1, 8(r2)
	sw $t1, r3)";

	std::istringstream iss(ins);
	TokenList t1 = tokenize(iss);
	REQUIRE(parse(t1).first);
}

TEST_CASE("test 19 should pass", "[virtualmachine]") {
	std::string ins = R"(
.data
var0:   .word 0
var1:   .word 1
var2:   .word 2
var3:   .word 3
        .text
main:
        lw $t0, var0
        lw $t1, var1
        lw $t2, var2
        lw $t3, var3

        beq $t0, $t1, check1
        beq $t0, $t0, check1
        nop
check1:
        bne $t0, $t0, check2
        bne $t0, $t1, check2
        nop
check2:
        bgt $t0, $t0, check3
        bgt $t3, $t1, check3
        nop
check3:
        bge $t0, $t1, check4
        bge $t3, $t2, check4
        nop
check4:
        blt $t3, $t1, check5
        blt $t1, $t3, check5
        nop
check5:
        ble $t3, $t1, check6
        ble $t3, $t3, check6
        nop
check6:
        nop
        j check6
	)";
	std::istringstream iss(ins);
	TokenList t1 = tokenize(iss);
	REQUIRE(parse(t1).first);

}

TEST_CASE("test 20 should pass", "[virtualmachine]") {
	std::string ins = R"(	# Example program to compute the sum of squares from Jorgensen [2016]

	#---------------------------------------------------------------
	# data declarations
	
	.data
n:		.word 10
sumOfSquares:	.word 0

	#---------------------------------------------------------------
	# the program
	.text
main:
	lw $t0,n
	li $t1,1
	li $t2,0

sumLoop:
	mult $t1, $t1
        mflo $t3
	add $t2, $t2, $t3
	add $t1, $t1, 1
	ble $t1, $t0, sumLoop
	sw  $t2, sumOfSquares

end:
	j end)";

	std::istringstream iss(ins);
	TokenList t1 = tokenize(iss);
	REQUIRE(parse(t1).first);
}

TEST_CASE("test 20 pass vm", "[virtualmachine]") {
	std::string ins = R"(	# Example program to compute the sum of squares from Jorgensen [2016]

	#---------------------------------------------------------------
	# data declarations
	
	.data
n:		.word 10
sumOfSquares:	.word 0

	#---------------------------------------------------------------
	# the program
	.text
main:
	lw $t0,n
	li $t1,1
	li $t2,0

sumLoop:
	mult $t1, $t1
        mflo $t3
	add $t2, $t2, $t3
	add $t1, $t1, 1
	ble $t1, $t0, sumLoop
	sw  $t2, sumOfSquares

end:
	j end)";

	std::istringstream iss(ins);
	TokenList t1 = tokenize(iss);
	REQUIRE(parse(t1).first);
	VirtualMachine vm = parse(t1).second;
	int pc = 1;
	//int count = 1;
	for (int i = 0; i < 35; i++) {
		REQUIRE(vm.registersArr[i] == 0);
	}
	VirtualMachine vm2 = vm.step(vm, pc).second;
	pc = vm2.pc;
	REQUIRE(pc == 2);
	REQUIRE(vm2.memArray[0] == 10);
	REQUIRE(vm2.getRegister("$zero") == 0);
	REQUIRE(vm2.getRegister("$pc") == 2);
}

