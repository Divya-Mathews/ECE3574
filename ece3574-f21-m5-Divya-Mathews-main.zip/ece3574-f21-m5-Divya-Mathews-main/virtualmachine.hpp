#ifndef VIRTUALMACHINE_HPP
#define VIRTUALMACHINE_HPP
#include <cstddef>
#include <vector>
#include <string>
#include <map>
#include <thread>
#include <algorithm>

enum FieldType {
	OPCODE//, ERROR_S
};
typedef struct {
	std::string opcode = "";
	std::string label = "";
	std::string oper1 = "";
	std::string oper2 = "";
	std::string oper3 = "";
	int offset = -1;

} Instruction;


class VirtualMachine {

public:
	VirtualMachine();
	~VirtualMachine();
	//bool VirtualMachine::run(VirtualMachine vm);
	std::pair<bool, VirtualMachine> step(VirtualMachine vm, int step) const;
	bool addWHBToMemory(std::string value, int bytes);
	void replaceMemoryWord(std::string value, int ptr);
	bool addSpaceToMemory(int bytes);
	bool addStringToMemory(std::string asc_type, std::string the_str);
	void addConstant(std::string constName, std::string intString);
	int getConstant(std::string constName);
	void addDataLabel(std::string label, std::pair <std::string, int> pointMem);
	std::pair <std::string, int> getDataLabel(std::string labelName);
	void addTextLabel(std::string label, int addr);
	int getTextLabel(std::string labelName);
	bool constantExists(std::string constName);
	bool dataLabelExists(std::string labelName);
	bool textLabelExists(std::string labelName);

	int getMemRefVal(int offset, int ptr);
	void setRegister(std::string reg, int64_t val);
	int getRegister(std::string oper);
	bool isConstantStr(std::string value);
	bool isAlpha(char c);
	bool isInteger(std::string value);
	bool isRegister(std::string regName);

	
	//std::vector<std::size_t> memory = std::vector<std::size_t> (1024, 0);
	unsigned char memArray[1024];
	int registersArr[35];
	std::map < std::string, std::pair <std::string, int> > dataLabels;
	std::map<std::string, int> textLabels;
	std::map<std::string, int> constants;
	std::vector<Instruction> program;
	int pc = 0;
	int totalCount = 0;
	int nextOpenMem = 0;

	std::vector<std::string> statusStack;

};

//void appendToStatus(std::string stat, VirtualMachine vm);

#endif