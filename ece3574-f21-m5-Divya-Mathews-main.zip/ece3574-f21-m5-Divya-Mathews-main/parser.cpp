#include "parser.hpp"
#include "virtualmachine.hpp"
#include <cstring>
#include <string>
#include <vector>
#include <tuple>
// implement the parser here


std::pair<bool, VirtualMachine> parse(const TokenList& tokens) {
	VirtualMachine vm;
	//bool parsed;
	std::pair<bool, VirtualMachine> final;
	//return 0;
	auto it = tokens.begin();
	StateType state = START;
	Instruction instr;
	std::string temp = "";
	std::string str_type = "";
	std::string maybeOffset = "";
	std::string instrString = "";
	int temp_bytes = 0;
	int temp_int = 0;
	int temp_memptr = 0;
	//std::vector<int> vec;
	//std::tuple <int, int> tup(0, 0);

	while ((it != tokens.end())) {
		switch (state) {
		case START:
			if (isComment(it->value())) state = PRE_DATA_COMMENT;
			//else if (it->value() == " ") state = START;
			else if (it->value() == ".data") state = DATA;
			else if (it->value() == ".text") state = TEXT_INTRO;
			else if (it->type() == EOL) state = START;
			else state = ERROR_P;
			++it;
			break;
		case DATA:
			if (isComment(it->value())) state = DATA_COMMENT;
			else if (it->value() == ".text") state = TEXT_INTRO;
			else if (isLabel(it->value())) {
				temp = it->value();
				state = LABEL;
			}
			else if (isConstantStr(it->value())) {
				temp = it->value();
				state = CONSTANT_STR;
			}
			else if (it->value() == ".word") {
				temp_bytes = 4;
				state = WHB_LAYOUT;
			}
			else if (it->value() == ".half") {
				temp_bytes = 2;
				state = WHB_LAYOUT;
			}
			else if (it->value() == ".byte") {
				temp_bytes = 1;
				state = WHB_LAYOUT;
			}
			else if (it->value() == ".space") state = SPACE_LAYOUT;
			else if (isStrLayout(it->value())) {
				str_type = it->value();
				state = ASCII_1;

			}
			else if (it->type() == EOL) state = DATA;
			else state = ERROR_P;
			++it;
			break;
		case PRE_DATA_COMMENT:
			if (it->type() == EOL) state = START;
			else state = PRE_DATA_COMMENT;
			++it;
			break;
		case DATA_COMMENT:
			if (it->type() == EOL) state = DATA;
			else state = DATA_COMMENT;
			++it;
			break;
		case CONSTANT_STR:
			if (it->type() == EQUAL) state = CONSTANT;
			else state = ERROR_P;
			++it;
			break;
		case CONSTANT:
			if (isInteger(it->value())) {
				vm.addConstant(temp, it->value());
				state = EOL_DATA;
			}
			else state = ERROR_P;
			++it;
			break;
		case LABEL:
			if (it->type() == EOL) state = DATA;
			else if (it->value() == ".word") {
				temp_bytes = 4;
				state = WHB_LAYOUT;
			}
			else if (it->value() == ".half") {
				temp_bytes = 2;
				state = WHB_LAYOUT;
			}
			else if (it->value() == ".byte") {
				temp_bytes = 1;
				state = WHB_LAYOUT;
			}
			else if (it->value() == ".space") state = SPACE_LAYOUT;
			else if (isStrLayout(it->value())) {
				str_type = it->value();
				state = ASCII_1;
			}
			else state = ERROR_P;
			++it;
			break;
		case WHB_LAYOUT:
			if (isInteger(it->value())) {
				temp_int = stoi(it->value());
				temp_memptr = vm.nextOpenMem;
				//vec.push_back(temp_int);
				if (vm.addWHBToMemory(it->value(), temp_bytes)) {
					state = COMMA;
				}
				else state = ERROR_P;
			}
			else if (isConstantStr(it->value()) && vm.constantExists(it->value())) {
				temp_int = vm.getConstant(it->value());
				temp_memptr = vm.nextOpenMem;
				//vec.push_back(temp_int);
				if (vm.addWHBToMemory(std::to_string(temp_int), temp_bytes))
					state = COMMA;
				else state = ERROR_P;
			}
			else state = ERROR_P;
			++it;
			break;
		case COMMA:
			if (it->type() == SEP) state = WHB_LAYOUT;
			else if (it->type() == EOL) {
				if (temp != "") {
					std::pair <std::string, int> tup(std::to_string(temp_int), temp_memptr);
					vm.addDataLabel(temp, tup);
				}
				temp.clear();
				//vec.clear();
				state = DATA;
			}
			else if (isComment(it->value())) {
				if (temp != "") {
					std::pair <std::string, int> tup(std::to_string(temp_int), temp_memptr);
					vm.addDataLabel(temp, tup);
				}
				temp.clear();
				//vec.clear();
				state = DATA_COMMENT;
			}
			else state = ERROR_P;
			++it;
			break;
		case ASCII_1:
			if (it->type() == STRING_DELIM) state = ASCII_2;
			else state = ERROR_P;
			++it;
			break;
		case ASCII_2:
			if (it->type() == STRING) {
				temp_memptr = vm.nextOpenMem;
				if (vm.addStringToMemory(str_type, it->value())) {
					if (temp != "") {
						std::pair <std::string, int> tup(it->value(), temp_memptr);
						vm.addDataLabel(temp, tup);
					}
					state = ASCII_3;
				}
				else state = ERROR_P;
			}
			else state = ERROR_P;
			++it;
			break;
		case ASCII_3:
			if (it->type() == STRING_DELIM) state = EOL_DATA;
			else state = ERROR_P;
			++it;
			break;
		case SPACE_LAYOUT:
			if (isInteger(it->value())) {
				int val = stoi(it->value());
				temp_memptr = vm.nextOpenMem;
				if (vm.addSpaceToMemory(val)) {
					if (temp != "") {
						std::pair <std::string, int> tup(it->value(), temp_memptr);
						vm.addDataLabel(temp, tup);
					}
					state = EOL_DATA;
				}
				else state = ERROR_P;
			}
			else if (isConstantStr(it->value()) && vm.constantExists(it->value())) {
				int val = vm.getConstant(it->value());
				temp_memptr = vm.nextOpenMem;
				if (vm.addSpaceToMemory(val)) {
					if (temp != "") {
						std::pair <std::string, int> tup(std::to_string(temp_int), temp_memptr);
						vm.addDataLabel(temp, tup);
					}
					state = EOL_DATA;
				}
				else state = ERROR_P;
			}
			else state = ERROR_P;
			++it;
			break;
		case EOL_DATA:
			if (isComment(it->value())) {
				temp.clear();
				state = DATA_COMMENT;
			}
			else if (it->type() == EOL) {
				temp.clear();
				state = DATA;
			}
			else state = ERROR_P;
			++it;
			break;
		case TEXT_INTRO:
			//Instruction instr;
			if (isComment(it->value())) state = TEXT_INTRO_COMMENT;
			else if (it->value() == "main:") {
				vm.pc = 0;
				vm.addTextLabel(it->value(), vm.pc);
				instr.label = it->value();
				state = TEXT;
			}
			else if (it->type() == EOL) state = TEXT_INTRO;
			else state = ERROR_P;
			++it;
			break;
		case TEXT_INTRO_COMMENT:
			if (it->type() == EOL) state = TEXT_INTRO;
			else state = TEXT_INTRO_COMMENT;
			++it;
			break;
		case TEXT:										//beginning of text section
			if (isComment(it->value())) state = TEXT_COMMENT;
			else if (isLabel(it->value())) {
				vm.addTextLabel(it->value(), vm.pc);
				instr.label = it->value();
				state = TEXT;
			}
			else if (it->value() == "nop") {
				instr.opcode = it->value();
				state = EOL_TEXT;
			}
			else if (it->value() == "j") {
				instr.opcode = it->value();
				state = JUMP;
			}
			else if (it->value() == "li") {
				instr.opcode = it->value();
				state = LI_1;
			}
			else if (it->value() == "not") {
				instr.opcode = it->value();
				state = NOT_1;
			}
			else if (it->value() == "div" || it->value() == "divu") {
				instr.opcode = it->value();
				state = DIV_1;
			}
			else if (isRR(it->value())) {
				instr.opcode = it->value();
				state = R_R1;
			}
			else if (isRM(it->value())) {
				instr.opcode = it->value();
				state = R_M1;
			}
			else if (isRRS(it->value())) {
				instr.opcode = it->value();
				state = R_R_S1;
			}
			else if (isR(it->value())) {
				instr.opcode = it->value();
				state = R;
			}
			else if (isRSL(it->value())) {
				instr.opcode = it->value();
				state = R_S_L1;
			}
			else if (it->type() == EOL) {
				if (instr.opcode != "") {
					vm.program.push_back(instr);
					vm.pc++;
					instr.label = "";
					instr.opcode = "";
					instr.oper1 = "";
					instr.oper2 = "";
					instr.oper3 = "";
					instr.offset = -1;
				}
				instr.label = "";
				state = TEXT;
			}
			else state = ERROR_P;
			++it;
			break;
		case TEXT_COMMENT:
			if (it->type() == EOL) { 
				if (instr.label != "" || instr.opcode != "") {
					vm.program.push_back(instr);
					vm.pc++;
					instr.label = "";
					instr.opcode = "";
					instr.oper1 = "";
					instr.oper2 = "";
					instr.oper3 = "";
					instr.offset = -1;
				}
				state = TEXT; 
			}
			else state = TEXT_COMMENT; 
			it++; 
			break;
		case JUMP:
			if (isConstantStr(it->value()) ) {//&& vm.textLabelExists(it->value())) {
				instr.oper1 = it->value();
				state = EOL_TEXT;
			}
			else state = ERROR_P;
			it++;
			break;
		case LI_1:
			if (isRegister(it->value())) {
				instr.oper1 = it->value();
				state = LI_2;
			}
			else state = ERROR_P;
			it++;
			break;
		case LI_2:
			if (it->type() == SEP) state = LI_3;
			else state = ERROR_P;
			it++;
			break;
		case LI_3:
			if (isImmediate(vm, it->value())) {
				instr.oper2 = it->value();
				state = EOL_TEXT;
			}
			else state = ERROR_P;
			it++;
			break;
		case NOT_1:
			if (isRegister(it->value())) {
				instr.oper1 = it->value();
				state = NOT_2;
			}
			else state = ERROR_P;
			it++;
			break;
		case NOT_2:
			if (it->type() == SEP) state = NOT_3;
			else state = ERROR_P;
			it++;
			break;
		case NOT_3:
			if (isSource(vm, it->value())) {
				instr.oper2 = it->value();
				state = EOL_TEXT;
			}
			else state = ERROR_P;
			it++;
			break;
		case DIV_1:
			if (isRegister(it->value())) {
				instr.oper1 = it->value();
				state = DIV_2;
			}
			else state = ERROR_P;
			it++;
			break;
		case DIV_2:
			if (it->type() == SEP) state = DIV_3;
			else state = ERROR_P;
			it++;
			break;
		case DIV_3:
			if (isRegister(it->value())) {
				instr.oper2 = it->value();
				state = DIV_4;
			}
			else state = ERROR_P;
			it++;
			break;
		case DIV_4:
			if (it->type() == SEP) state = DIV_5;
			else if (it->type() == EOL) {
				vm.program.push_back(instr);
				vm.pc++;
				instr.label = "";
				instr.opcode = "";
				instr.oper1 = "";
				instr.oper2 = "";
				instr.oper3 = "";
				instr.offset = -1;
				state = TEXT;
			}
			else if (isComment(it->value())) {
				vm.program.push_back(instr);
				vm.pc++;
				instr.label = "";
				instr.opcode = "";
				instr.oper1 = "";
				instr.oper2 = "";
				instr.oper3 = "";
				instr.offset = -1;
				state = TEXT_COMMENT;
			}
			else state = ERROR_P;
			it++;
			break;
		case DIV_5:
			if (isSource(vm, it->value())) {
				instr.oper3 = it->value();
				state = EOL_TEXT;
			}
			else state = ERROR_P;
			it++;
			break;
		case R_R1:
			if (isRegister(it->value())) {
				instr.oper1 = it->value();
				state = R_R2;
			}
			else state = ERROR_P;
			it++;
			break;
		case R_R2:
			if (it->type() == SEP) state = R_R3;
			else state = ERROR_P;
			it++;
			break;
		case R_R3:
			if (isRegister(it->value())) {
				instr.oper2 = it->value();
				state = EOL_TEXT;
			}
			else state = ERROR_P;
			it++;
			break;
		case R_M1:
			if (isRegister(it->value())) {
				instr.oper1 = it->value();
				state = R_M2;
			}
			else state = ERROR_P;
			it++;
			break;
		case R_M2:
			if (it->type() == SEP) state = R_M3;
			else state = ERROR_P;
			it++;
			break;
		case R_M3:
			if (isConstantStr(it->value()) && (vm.dataLabelExists(it->value()) || vm.constantExists(it->value()))) {
				instr.oper2 = it->value();
				state = EOL_TEXT;
			}
			else if (isRegister(it->value())) {
				instr.oper2 = it->value();
				state = EOL_TEXT;
			}
			else if (isInteger(it->value())) {
				//instr.offset = stoi(it->value());
				maybeOffset = it->value();
				state = R_M3_1;
			}
			else if (it->type() == OPEN_PAREN) {
				instr.offset = 0;
				state = R_M4;
			}
			else state = ERROR_P;
			it++;
			break;
		case R_M3_1:
			if (it->type() == OPEN_PAREN) { 
				instr.offset = stoi(maybeOffset);
				state = R_M4; 
			}
			else if (it->type() == EOL) {
				instr.oper2 = maybeOffset;
				vm.program.push_back(instr);
				vm.pc++;
				instr.label = "";
				instr.opcode = "";
				instr.oper1 = "";
				instr.oper2 = "";
				instr.oper3 = "";
				instr.offset = -1;
				state = TEXT;
			}
			else state = ERROR_P;
			it++;
			break;
		case R_M4:
			if (isRegister(it->value())) {
				instr.oper2 = it->value();
				state = R_M5;
			}
			else if (isConstantStr(it->value()) && (vm.dataLabelExists(it->value()))) {
				instr.oper2 = it->value();
				state = R_M5;
			}
			else if (isImmediate(vm, it->value())) {	//is integer
				instr.oper2 = it->value();
				state = R_M5;
			}
			else state = ERROR_P;
			it++;
			break;
		case R_M5:
			if (it->type() == CLOSE_PAREN) state = TEXT_COMMENT;
			else state = ERROR_P;
			it++;
			break;
		case R_R_S1:
			if (isRegister(it->value())) {
				instr.oper1 = it->value();
				state = R_R_S2;
			}
			else state = ERROR_P;
			it++;
			break;
		case R_R_S2:
			if (it->type() == SEP) state = R_R_S3;
			else state = ERROR_P;
			it++;
			break;
		case R_R_S3:
			if (isRegister(it->value())) {
				instr.oper2 = it->value();
				state = R_R_S4;
			}
			else state = ERROR_P;
			it++;
			break;
		case R_R_S4:
			if (it->type() == SEP) state = R_R_S5;
			else state = ERROR_P;
			it++;
			break;
		case R_R_S5:
			if (isSource(vm, it->value())) {
				instr.oper3 = it->value();
				state = EOL_TEXT;
			}
			else state = ERROR_P;
			it++;
			break;
		case R:
			if (isRegister(it->value())) {
				instr.oper1 = it->value();
				state = EOL_TEXT;
			}
			else state = ERROR_P;
			it++;
			break;
		case R_S_L1:
			if (isRegister(it->value())) {
				instr.oper1 = it->value();
				state = R_S_L2;
			}
			else state = ERROR_P;
			it++;
			break;
		case R_S_L2:
			if (it->type() == SEP) state = R_S_L3;
			else state = ERROR_P;
			it++;
			break;
		case R_S_L3:
			if (isSource(vm, it->value())) {
				instr.oper2 = it->value();
				state = R_S_L4;
			}
			else state = ERROR_P;
			it++;
			break;
		case R_S_L4:
			if (it->type() == SEP) state = R_S_L5;
			else state = ERROR_P;
			it++;
			break;
		case R_S_L5:
			if (isConstantStr(it->value())) {
				instr.oper3 = it->value();
				state = EOL_TEXT;
			}
			else state = ERROR_P;
			it++;
			break;
		case EOL_TEXT:
			if (isComment(it->value())) state = TEXT_COMMENT;
			else if (it->type() == EOL) {
				vm.program.push_back(instr);
				vm.pc++;
				instr.label = "";
				instr.opcode = "";
				instr.oper1 = "";
				instr.oper2 = "";
				instr.oper3 = "";
				instr.offset = -1;
				state = TEXT;	//here is where you push back instruction
			}
			else state = ERROR_P;
			it++;
			break;
		case ERROR_P:
			final.first = false;
			final.second = vm;
			return final;
		default:
			state = ERROR_P;
			break;
		}
	}
	vm.totalCount = vm.pc;
	final.first = true;
	final.second = vm;
	return final;
}


bool isConstantStr(std::string value) {
	bool is = false;
	if (isAlpha(value[0])) {
		for (std::size_t i = 1; i < value.length(); i++) {
			if (!isAlpha(value[i]) && !isdigit(value[i]))
				return false;
		}
		is = true;
	}
	return is;
}

bool isLabel(std::string value) {
	bool is = false;
	if (isAlpha(value[0]) && (value[value.length() - 1] == ':')) {
		for (std::size_t i = 1; i < value.length() - 1; i++) {
			if (!isAlpha(value[i]) && !isdigit(value[i]))
				return false;
		}
		is = true;
	}
	return is;
}

bool isInteger(std::string value) {
	bool is = false;
	if (value[0] == '-' || value[0] == '+' || isdigit(value[0])) {
		for (std::size_t i = 1; i < value.length(); i++) {
			if (!isdigit(value[i]))
				return false;
		}
		is = true;
	}
	return is;
}

bool isComment(std::string value) {
	if (value[0] == '#')
		return true;
	else return false;
}

bool isAlpha(char c) {
	return ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == '_');
}


bool isStrLayout(std::string value) {
	return (value == ".ascii" || value == ".asciiz");
}

bool isIntLayout(std::string value) {
	return (value == ".word" || value == ".half" || value == ".byte");
}

bool isRR(std::string value) {
	return (value == "move" || value == "mult" || value == "multu" || value == "abs" || value == "neg" || value == "negu");
}

bool isR(std::string value) {
	return (value == "mfhi" || value == "mflo" || value == "mthi" || value == "mtlo");
}

bool isRRS(std::string value) {
	return (value == "add" || value == "addu" || value == "sub" || value == "subu" || value == "mul" || value == "mulo" || value == "mulou" || value == "rem" || value == "remu"
		|| value == "and" || value == "nor" || value == "or" || value == "xor");
}

bool isRSL(std::string value) {
	return (value == "beq" || value == "bne" || value == "blt" || value == "ble" || value == "bgt" || value == "bge");
}

bool isRM(std::string value) {
	return (value == "lw" || value == "lh" || value == "lb" || value == "la" || value == "sw" || value == "sh" || value == "sb");
}

bool isRegister(std::string value) {
	bool is = false;
	if (value[0] == '$') {
		for (std::size_t i = 1; i < value.length(); i++) {
			if (!isAlpha(value[i]) && !isdigit(value[i]))
				return false;
		}
		is = true;
	}
	return is;
}

bool isImmediate(VirtualMachine vm, std::string value) {
	return (isInteger(value) || (isConstantStr(value) && (vm.constantExists(value) || vm.dataLabelExists(value)) ));
}

bool isSource(VirtualMachine vm, std::string value) {
	return (isRegister(value) || isImmediate(vm, value));
}
