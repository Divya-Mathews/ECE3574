#include "catch.hpp"
#include "token.hpp"
#include "lexer.hpp"
#include "parser.hpp"
#include <string>
#include <sstream>
#include <iostream>
#include <map>
#include "virtualmachine.hpp"

TEST_CASE("test hex function", "[virtualmachine]") {
	//std::string s = "20";
	//int decimal_value = stoi(s);
	//std::stringstream ss;
	//ss << std::hex << decimal_value; // int decimal_value
	//std::string res(ss.str());
	//int val = stoi(res);
	//std::cout << val;

}

TEST_CASE("test bitmask", "[virtualmachine]") {
	unsigned char memArray[32];
	std::string s = "20";
	long int decimal = stoi(s);
	memArray[3] = (int)((decimal >> 24) & 0xFF);
	memArray[2] = (int)((decimal >> 16) & 0xFF);
	memArray[1] = (int)((decimal >> 8) & 0XFF);
	memArray[0] = (int)((decimal & 0XFF));
	
	REQUIRE(memArray[0] == 20);

	std::string r = "-21";
	long int decimal_1 = stoi(r);
	memArray[7] = (int)((decimal_1 >> 24) & 0xFF);
	memArray[6] = (int)((decimal_1 >> 16) & 0xFF);
	memArray[5] = (int)((decimal_1 >> 8) & 0XFF);
	memArray[4] = (int)((decimal_1 & 0XFF));
	REQUIRE(memArray[4] == 235);

}

TEST_CASE("test memory adding", "[virtualmachine]") {
	VirtualMachine vm;
	REQUIRE(vm.addWHBToMemory("5", 1));
	REQUIRE(vm.memArray[0] == 5);
	REQUIRE(vm.addWHBToMemory("12", 4));
	REQUIRE(vm.memArray[1] == 12);
	REQUIRE(vm.memArray[2] == 0);
	//REQUIRE(vm.memArray[5] == NULL);
	REQUIRE(vm.addSpaceToMemory(2));
	REQUIRE(vm.memArray[5] == 0);
	REQUIRE(vm.addStringToMemory(".ascii", "test"));
	REQUIRE(vm.memArray[7] == int('t'));
	REQUIRE(vm.memArray[10] == int('t'));
	REQUIRE(vm.addStringToMemory(".asciiz", "test2"));
	REQUIRE(vm.memArray[11] == int('t'));
	REQUIRE(vm.memArray[15] == int('2'));
	REQUIRE(vm.memArray[16] == 0);
	//std::cout << vm.memArray[0];
}

//TEST_CASE("test 01 passes", "[virtualmachine]") {
//	std::string ins = R"(	
//# a test for constants
//	.data
//	LENGTH = 1024
//arr:	.space LENGTH
//	
//	.text)";
//	std::istringstream iss(ins);
//	TokenList t1 = tokenize(iss);
//	REQUIRE(parse(t1).first);
//	VirtualMachine vm = parse(t1).second;
//	REQUIRE(parse(t1).second.memArray[1023] == 0);
//}
//
//TEST_CASE("test 00 passes", "[virtualmachine]") {
//	std::string ins = R"(	
//# A test file of data declarations only
//	.data
//var1:	.word 1024             # int var1 = 1024
//
//var2:	.half 12               # short var2 = 12
//	
//var3:	.byte 0                # char var3 = 0
//
//var4:	.byte 1, 2, 3, 4, 5, 6, 7, 8  # var4 = {1,2,3,4,5,6,7,8}
//
//var5:	.space 512             # reserve 512 bytes
//
//var6:	.ascii "hello"
//
//var7:	.asciiz "goodbye"
//
//	.text)";
//	std::istringstream iss(ins);
//	TokenList t1 = tokenize(iss);
//	REQUIRE(parse(t1).first);
//	
//}
//
//TEST_CASE("test 00 fails", "[virtualmachine]") {
//	std::string ins = R"(	
//# A test file of data declarations only
//	.data
//var1:	.word 1024             # int var1 = 1024
//
//var2:	.half 12               # short var2 = 12
//	
//var3:	.byte 0                # char var3 = 0
//
//var4:	.byte 1, 2, 3, 4, 5, 6, 7,   # PARSE ERROR
//
//var5:	.space 512             # reserve 512 bytes
//
//var6:	.ascii "hello"
//
//var7:	.asciiz "goodbye"
//
//	.text)";
//	std::istringstream iss(ins);
//	TokenList t1 = tokenize(iss);
//	REQUIRE_FALSE(parse(t1).first);
//}

//TEST_CASE("test 05 passes text", "[virtualmachine]") {
//	std::string ins = R"(        
//.data
//VALUE = -1
//var:    .word 1
//        .text
//main:
//        lw $t0, var
//        add $t1, $t0, VALUE
//        add $t2, $t1, $t0)";
//	std::istringstream iss(ins);
//	TokenList t1 = tokenize(iss);
//	REQUIRE(parse(t1).first);
//}

TEST_CASE("test 01 should pass", "[virtualmachine]") {
	std::string ins = R"(       
        .data
r1:     .space 4
r2:     .space 12
r3:     .space 4
var:    .word 7

        .text
main:
        la $t0, r2
     	lw $t1, var

	sw $t1, 0
	sw $t1, $t0
	sw $t1, 4($t0)
	sw $t1, 8(r2)
	sw $t1, r3)";

	std::istringstream iss(ins);
	TokenList t1 = tokenize(iss);
	REQUIRE(parse(t1).first);
	//REQUIRE(simulate(parse(t1).second).first);
}

//TEST_CASE("test 19 should pass", "[virtualmachine]") {
//	std::string ins = R"(
//.data
//var0:   .word 0
//var1:   .word 1
//var2:   .word 2
//var3:   .word 3
//        .text
//main:
//        lw $t0, var0
//        lw $t1, var1
//        lw $t2, var2
//        lw $t3, var3
//
//        beq $t0, $t1, check1
//        beq $t0, $t0, check1
//        nop
//check1:
//        bne $t0, $t0, check2
//        bne $t0, $t1, check2
//        nop
//check2:
//        bgt $t0, $t0, check3
//        bgt $t3, $t1, check3
//        nop
//check3:
//        bge $t0, $t1, check4
//        bge $t3, $t2, check4
//        nop
//check4:
//        blt $t3, $t1, check5
//        blt $t1, $t3, check5
//        nop
//check5:
//        ble $t3, $t1, check6
//        ble $t3, $t3, check6
//        nop
//check6:
//        nop
//        j check6
//	)";
//	std::istringstream iss(ins);
//	TokenList t1 = tokenize(iss);
//	REQUIRE(parse(t1).first);
//
//}

