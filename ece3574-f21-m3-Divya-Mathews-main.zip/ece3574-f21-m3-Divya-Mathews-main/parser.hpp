#ifndef PARSER_HPP
#define PARSER_HPP
#include "lexer.hpp"
#include "virtualmachine.hpp"
// define the parser module here
//enum StateType { DATA, CONSTANT, LABEL, LAYOUT, EOL, TEXT };

//class Parser {
//public:
//
//};
enum StateType {
	MAIN, START, DATA, PRE_START_COMMENT, PRE_DATA_COMMENT, DATA_COMMENT, LABEL, CONSTANT_STR, WHB_LAYOUT, SPACE_LAYOUT, ASCII_1, ASCII_2, ASCII_3, CONSTANT, EOL_DATA, COMMA, TEXT_INTRO, TEXT_INTRO_COMMENT, TEXT, ERROR_P,
	TEXT_COMMENT, JUMP, LI_1, LI_2, LI_3, NOT_1, NOT_2, NOT_3, DIV_1, DIV_2, DIV_3, DIV_4, DIV_5, R_R1, R_R2, R_R3, R_M1, R_M2, R_M3, R_M3_1, R_M4, R_M5, R_R_S1, R_R_S2, R_R_S3, R_R_S4, R_R_S5, R, R_S_L1,
	R_S_L2, R_S_L3, R_S_L4, R_S_L5, EOL_TEXT
};

std::pair<bool, VirtualMachine> parse(const TokenList& tokens);
bool isConstantStr(std::string value);
bool isLabel(std::string value);
bool isInteger(std::string value);
bool isAlpha(char c);
bool isComment(std::string value);
bool isStrLayout(std::string value);
bool isIntLayout(std::string value);
bool isR(std::string value);
bool isRR(std::string value);
bool isRM(std::string value);
bool isRRS(std::string value);
bool isRSL(std::string value);
bool isRegister(std::string value);
bool isImmediate(VirtualMachine vm, std::string value);
bool isSource(VirtualMachine vm, std::string value);

#endif
