#include "catch.hpp"
#include "parser.hpp"
#include "lexer.hpp"
#include <string>
#include <fstream>
#include <istream>
#include <iostream>
#include <string>
#include <sstream>
#include <map>

// put your parser tests here
TEST_CASE("test isAlpha", "[parser]") {
	char c = 'f';
	REQUIRE(isAlpha(c));

	c = 'a';
	REQUIRE(isAlpha(c));

	c = '1';
	REQUIRE_FALSE(isAlpha(c));
}

TEST_CASE("test isConstant", "[parser]") {

	std::string a = "a123";
	REQUIRE(isConstantStr(a));

	a = "123";
	REQUIRE_FALSE(isConstantStr(a));

	a = "ab!5";
	REQUIRE_FALSE(isConstantStr(a));

	a = "wor_d";
	REQUIRE(isConstantStr(a));

	a = "label:";
	REQUIRE_FALSE(isConstantStr(a));
}

TEST_CASE("test isLabel", "[parser]") {
	std::string b = "label:";
	REQUIRE(isLabel(b));

	b = "constant";
	REQUIRE_FALSE(isLabel(b));

}

TEST_CASE("test isInteger", "[parser]") {
	std::string c = "20";
	REQUIRE(isInteger(c));

	c = "a20";
	REQUIRE_FALSE(isInteger(c));
}

TEST_CASE("test isComment", "[parser]") {
	std::string d = "#comment";
	REQUIRE(isComment(d));

	d = "notcomment";
	REQUIRE_FALSE(isComment(d));
}
TEST_CASE("test data section of parse", "[parser]") {
//	{
//		// test start
//		std::string ins = ".data \n";
//		std::istringstream iss(ins);
//		TokenList t1 = tokenize(iss);
//		REQUIRE(parse(t1).first);
//	}
//
//	{
//		// test start
//		std::string ins = ".dala \n";
//		std::istringstream iss(ins);
//		TokenList t1 = tokenize(iss);
//		REQUIRE_FALSE(parse(t1).first);
//	}
//
//	{
//		std::string ins = "	# A test file of data declarations only\n.data\nvar1: .word 1024 # int var1 = 1024\n";// \n.text";
//		std::istringstream iss(ins);
//		TokenList t1 = tokenize(iss);
//		//for (auto v : t1)
//		//	std::cout << v << "\n";
//		REQUIRE(parse(t1).first);
//	}
//
//	{
//		//test FAIL
//		std::string ins = R"(
//# A test file of data declarations only
//.data
//var1:	.word 1024             # int var1 = 1024
//
//var2:	.half 12               # short var2 = 12
//	
//var3:	.byte 0                # char var3 = 0
//
//var4:	.byte 1, 2, 3, 4, 5, 6, 7,   # PARSE ERROR
//
//var5:	.space 512             # reserve 512 bytes
//
//var6:	.ascii "hello"
//
//var7:	.asciiz "goodbye"
//
//	.text)";
//		std::istringstream iss(ins);
//		TokenList t1 = tokenize(iss);
//		REQUIRE_FALSE(parse(t1).first);
//	}
//	{
//		//test PASS
//		std::string ins = R"(	
//# A test file of data declarations only
//.data
//var1:	.word 1024             # int var1 = 1024
//
//var2:	.half 12               # short var2 = 12
//	
//var3:	.byte 0                # char var3 = 0
//
//var4:	.byte 1, 2, 3, 4, 5, 6, 7, 8  # var4 = {1,2,3,4,5,6,7,8}
//
//var5:	.space 512             # reserve 512 bytes
//
//var6:	.ascii "hello"
//
//var7:	.asciiz "goodbye"
//
//	.text)";
//		std::istringstream iss(ins);
//		TokenList t1 = tokenize(iss);
//		REQUIRE(parse(t1).first);
//
//	}
//
//	{
//		std::string ins = R"(
//	# a test for constants
//	.data
//	LENGTH = 1024
//arr:	.space LENGTH
//	
//	.text)";
//		std::istringstream iss(ins);
//		TokenList t1 = tokenize(iss);
//		REQUIRE(parse(t1).first);
//
//	}
}

TEST_CASE("test text section of parser", "[parser]") {
	/*{
		std::string ins = R"(
.data
.text
main:	
	li $t0, 45
	lw $t1, avar
	lh $t2, bvar
	lb $t2, cvar
	sw $t1, avar
	sh $t2, bvar
	sb $t2, cvar

	move $t0, $0)";
		std::istringstream iss(ins);
		TokenList t1 = tokenize(iss);
		REQUIRE_FALSE(parse(t1).first);
	}

	{
		std::string ins = R"(
	# test of basic logical instructions
	.data
	TRUE = 1
	FALSE = 0

test1:	.word TRUE
test2:	.word FALSE
	
	.text
main:
	lw	$t0, test1
	lw	$t1, test2
	
	and	$t2, $t0, $t1
	and	$t2, $t0, TRUE
	nor	$t2, $t0, $t1
	nor	$t2, $t0, TRUE
	not	$t2, $t0
	not	$t2, $t0
	or	$t2, $t0, $t1
	or	$t2, $t0, TRUE
	xor	$t2, $t0, $t1
	xor	$t2, $t0, TRUE)";
		std::istringstream iss(ins);
		TokenList t1 = tokenize(iss);
		REQUIRE(parse(t1).first);
	}*/

	{
		std::string ins = R"(
	.text
main:
next3:
	ble $t0, $t0, next4	
end:
	j	end)";
		std::istringstream iss(ins);
		TokenList t1 = tokenize(iss);
		REQUIRE(parse(t1).first); //REQUIRE_FALSE

	}

//	{
//		std::string ins = R"(
//	# Example program to compute the sum of squares from Jorgensen [2016]
//
//	#---------------------------------------------------------------
//	# data declarations
//	
//	.data
//n:		.word 10
//sumOfSquares:	.word 0
//
//	#---------------------------------------------------------------
//	# the program
//main:
//	lw $t0,n
//	li $t1,1
//	li $t2,0
//
//sumLoop:
//	mul $t3, $t1, $t1
//	add $t2, $t2, $t3
//	add $t1, $t1, 1
//	ble $t1, $t0, sumLoop
//	sw  $t2, sumOfSquares
//
//end:
//	j end)";
//		std::istringstream iss(ins);
//		TokenList t1 = tokenize(iss);
//		REQUIRE_FALSE(parse(t1).first);
//	}
}
