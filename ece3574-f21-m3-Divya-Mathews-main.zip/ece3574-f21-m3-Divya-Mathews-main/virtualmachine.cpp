#include "virtualmachine.hpp"
#include <tuple>
#include <limits>
#include <cstring>
#include <string>


VirtualMachine::VirtualMachine() {
	for (int i = 0; i < 35; i++) {
		registersArr[i] = 0;
	}
	for (int i = 0; i < 1024; i++) {
		memArray[i] = 0;
	}
}

std::pair<bool, VirtualMachine> VirtualMachine::step(VirtualMachine vm, int step) {
	vm.pc = step;
	bool simulated = true;

	//if (vm.pc < vm.totalCount) {
	Instruction it = vm.program[step];
	if (it.opcode == "nop") {
		vm.pc++;
		vm.setRegister("$pc", vm.pc);
	}
	else if (it.opcode == "lw") {
		if (it.offset == -1) {
			int val = -1;
			if (vm.isConstantStr(it.oper2)) {		//if data label or constant
				if (vm.dataLabelExists(it.oper2)) {
					val = stoi(vm.getDataLabel(it.oper2).first);
				}
				else if (vm.constantExists(it.oper2)) {// implied constant
					val = vm.getConstant(it.oper2);
				}
				else {
					simulated = false;
					//break;
				}
				vm.setRegister(it.oper1, val);
				vm.pc++;
				vm.setRegister("$pc", vm.pc);
			}
			else if (vm.isInteger(it.oper2)) {
				vm.setRegister(it.oper1, stoi(it.oper2));
				vm.pc++;
				vm.setRegister("$pc", vm.pc);
			}
			else if (vm.isRegister(it.oper2)) { // implied register
				int ptr = vm.getRegister(it.oper2);
				int val = vm.getMemRefVal(0, ptr);
				vm.setRegister(it.oper1, val);
				vm.pc++;
				vm.setRegister("$pc", vm.pc);
			}
			else {
				simulated = false;
			}
		}
		else { // offset on
			int val = -1;
			if (vm.isConstantStr(it.oper2)) {
				int ptr = vm.getDataLabel(it.oper2).second;
				val = vm.getMemRefVal(it.offset, ptr);
				vm.setRegister(it.oper1, val);
				vm.pc++;
				vm.setRegister("$pc", vm.pc);
			}
			else if (vm.isInteger(it.oper2)) {
				int ptr = stoi(it.oper2);
				val = vm.getMemRefVal(it.offset, ptr);
				vm.setRegister(it.oper1, val);
				vm.pc++;
				vm.setRegister("$pc", vm.pc);
			}
			else if (vm.isRegister(it.oper2)) { // implied register
				int ptr = vm.getRegister(it.oper2);
				val = vm.getMemRefVal(it.offset, ptr);
				vm.setRegister(it.oper1, val);
				vm.pc++;
				vm.setRegister("$pc", vm.pc);


			}
			else {
				simulated = false;
				//break;
			}

		}
	}
	else if (it.opcode == "li") {
		if (vm.isInteger(it.oper2)) {
			vm.setRegister(it.oper1, stoi(it.oper2));
			vm.pc++;
			vm.setRegister("$pc", vm.pc);
		}
		else {	// implied constant string
			int val = vm.getConstant(it.oper2);
			vm.setRegister(it.oper1, val);
			vm.pc++;
			vm.setRegister("$pc", vm.pc);
		}
	}
	else if (it.opcode == "la") {
		//did not account for offset in this code to reflect m3 tests
		int val = vm.getDataLabel(it.oper2).second;
		vm.setRegister(it.oper1, val);
		vm.pc++;
		vm.setRegister("$pc", vm.pc);
	}
	else if (it.opcode == "sw") {
		int val = vm.getRegister(it.oper1);
		if (it.offset == -1) {
			if (vm.isConstantStr(it.oper2)) {		//if data label or constant
				if (vm.constantExists(it.oper2)) {
					vm.constants.erase(it.oper2);
					vm.addConstant(it.oper2, std::to_string(val));
					vm.pc++;
					vm.setRegister("$pc", vm.pc);
				}
				else if (vm.dataLabelExists(it.oper2)) {
					int ptr = vm.getDataLabel(it.oper2).second;
					vm.dataLabels.erase(it.oper2);
					vm.replaceMemoryWord(std::to_string(val), ptr);
					std::pair <std::string, int> tup(std::to_string(val), ptr);
					vm.addDataLabel(it.oper2, tup);
					vm.pc++;
					vm.setRegister("$pc", vm.pc);
				}
				else {
					simulated = false;
					//break;
				}
			}
			else if (vm.isInteger(it.oper2)) {	// memory
				vm.replaceMemoryWord(std::to_string(val), stoi(it.oper2));
				vm.pc++;
				vm.setRegister("$pc", vm.pc);
			}
			else if (vm.isRegister(it.oper2)) { // implied register
				//vm.setRegister(it->oper2, val);
				int ptr = vm.getRegister(it.oper2);
				//int addr = vm.getMemRefVal(0, ptr);
				vm.replaceMemoryWord(std::to_string(val), ptr);
				vm.setRegister(it.oper2, ptr);
				vm.pc++;
				vm.setRegister("$pc", vm.pc);
			}
			else {
				simulated = false;
				//break;
			}
		}
		else { // offset on, integer not handled
			if (vm.isConstantStr(it.oper2)) {	// is data label
				int ptr = vm.getDataLabel(it.oper2).second;
				int addr = it.offset + ptr;
				vm.replaceMemoryWord(std::to_string(val), addr);
				vm.pc++;
				vm.setRegister("$pc", vm.pc);
			}
			else if (vm.isRegister(it.oper2)) { // implied register
				int ptr = vm.getRegister(it.oper2);
				int addr = it.offset + ptr;
				vm.replaceMemoryWord(std::to_string(val), addr);
				vm.pc++;
				vm.setRegister("$pc", vm.pc);
			}
			else {
				simulated = false;
				//break;
			}

		}
	}
	else if (it.opcode == "move") {
		int val = vm.getRegister(it.oper2);
		vm.setRegister(it.oper1, val);
		vm.pc++;
		vm.setRegister("$pc", vm.pc);
	}
	else if (it.opcode == "j") {
		vm.pc = vm.getTextLabel(it.oper1);
		vm.setRegister("$pc", vm.pc);
		//break;
	}
	else if (it.opcode == "beq") {
		int val1 = vm.getRegister(it.oper1);
		int val2 = vm.getRegister(it.oper2);
		if (val1 == val2) {
			vm.pc = vm.getTextLabel(it.oper3);
			vm.setRegister("$pc", vm.pc);
		}
		else {
			vm.pc++;
			vm.setRegister("$pc", vm.pc);
		}
	}
	else if (it.opcode == "bne") {
		int val1 = vm.getRegister(it.oper1);
		int val2 = vm.getRegister(it.oper2);
		if (val1 != val2) {
			vm.pc = vm.getTextLabel(it.oper3);
			vm.setRegister("$pc", vm.pc);
		}
		else {
			vm.pc++;
			vm.setRegister("$pc", vm.pc);
		}
	}
	else if (it.opcode == "bgt") {
		int val1 = vm.getRegister(it.oper1);
		int val2 = vm.getRegister(it.oper2);
		if (val1 > val2) {
			vm.pc = vm.getTextLabel(it.oper3);
			vm.setRegister("$pc", vm.pc);
		}
		else {
			vm.pc++;
			vm.setRegister("$pc", vm.pc);
		}
	}
	else if (it.opcode == "bge") {
		int val1 = vm.getRegister(it.oper1);
		int val2 = vm.getRegister(it.oper2);
		if (val1 >= val2) {
			vm.pc = vm.getTextLabel(it.oper3);
			vm.setRegister("$pc", vm.pc);
		}
		else {
			vm.pc++;
			vm.setRegister("$pc", vm.pc);
		}
	}
	else if (it.opcode == "blt") {
		int val1 = vm.getRegister(it.oper1);
		int val2 = vm.getRegister(it.oper2);
		if (val1 < val2) {
			vm.pc = vm.getTextLabel(it.oper3);
			vm.setRegister("$pc", vm.pc);
		}
		else {
			vm.pc++;
			vm.setRegister("$pc", vm.pc);
		}
	}
	else if (it.opcode == "ble") {
		int val1 = vm.getRegister(it.oper1);
		int val2 = vm.getRegister(it.oper2);
		if (val1 <= val2) {
			vm.pc = vm.getTextLabel(it.oper3);
			vm.setRegister("$pc", vm.pc);
		}
		else {
			vm.pc++;
			vm.setRegister("$pc", vm.pc);
		}
	}
	else if (it.opcode == "add") {
		long int sum;
		std::string resultreg = it.oper1;
		std::string addreg = it.oper2;
		uint32_t val2 = vm.getRegister(addreg);
		if (vm.isRegister(it.oper3)) {
			uint32_t val3 = vm.getRegister(it.oper3);
			int64_t sum = (int64_t)val2 + (int64_t)val3;
			//if (sum < std::numeric_limits<uint32_t>::max()) {
			vm.setRegister(resultreg, sum);
			vm.pc++;
			vm.setRegister("$pc", vm.pc);
			//}
			//else {
			//	simulated = false;
			//	break;
			//}
		}
		else if (vm.isConstantStr(it.oper3)) {
			if (vm.constantExists(it.oper3)) {
				int val3 = vm.getConstant(it.oper3);
				if ((val2 + val3) < std::numeric_limits<uint32_t>::max()) {
					sum = val2 + val3;
					vm.setRegister(resultreg, sum);
					vm.pc++;
					vm.setRegister("$pc", vm.pc);
				}
				else {
					simulated = false;
					//break;
				}
			}
			else if (vm.dataLabelExists(it.oper3)) {
				int val3 = stoi(vm.getDataLabel(it.oper3).first);
				if ((val2 + val3) < std::numeric_limits<uint32_t>::max()) {
					sum = val2 + val3;
					vm.setRegister(resultreg, sum);
					vm.pc++;
					vm.setRegister("$pc", vm.pc);
				}
				else {
					simulated = false;
					//break;
				}
			}
			else {
				simulated = false;
				//break;
			}
		}
		else if (isInteger(it.oper3)) {
			int val3 = stoi(it.oper3);
			int64_t sum = (int64_t)val2 + (int64_t)val3;
			vm.setRegister(resultreg, sum);
			vm.pc++;
			vm.setRegister("$pc", vm.pc);
		}
		else {
			simulated = false;
			//break;
		}
	}
	else if (it.opcode == "addu") {
		long int sum;
		std::string resultreg = it.oper1;
		std::string addreg = it.oper2;
		int val2 = vm.getRegister(addreg);
		if (vm.isRegister(it.oper3)) {
			int val3 = vm.getRegister(it.oper3);
			sum = val2 + val3;
			vm.setRegister(resultreg, sum);
			vm.pc++;
			vm.setRegister("$pc", vm.pc);
		}
		else if (vm.isConstantStr(it.oper3)) {
			if (vm.constantExists(it.oper3)) {
				int val3 = vm.getConstant(it.oper3);
				sum = val2 + val3;
				vm.setRegister(resultreg, sum);
				vm.pc++;
				vm.setRegister("$pc", vm.pc);
			}
			else if (vm.dataLabelExists(it.oper3)) {
				int val3 = stoi(vm.getDataLabel(it.oper3).first);
				sum = val2 + val3;
				vm.setRegister(resultreg, sum);
				vm.pc++;
				vm.setRegister("$pc", vm.pc);
			}
			else {
				simulated = false;
				//break;
			}
		}
		else {
			simulated = false;
			//break;
		}
	}
	else if (it.opcode == "mult") {
		int val1 = vm.getRegister(it.oper1);
		int val2 = vm.getRegister(it.oper2);
		int64_t product = int64_t(val1) * int64_t(val2);
		vm.setRegister("$hi", (int64_t)(product) >> 32);
		vm.setRegister("$lo", (uint64_t)(product));
		vm.pc++;
		vm.setRegister("$pc", vm.pc);
	}
	else if (it.opcode == "mfhi") {
		int val = vm.getRegister("$hi");
		vm.setRegister(it.oper1, val);
		vm.pc++;
		vm.setRegister("$pc", vm.pc);
	}
	else if (it.opcode == "mflo") {
		int val = vm.getRegister("$lo");
		vm.setRegister(it.oper1, val);
		vm.pc++;
		vm.setRegister("$pc", vm.pc);
	}
	else if (it.opcode == "ble") {
		int val1 = vm.getRegister(it.oper1);
		int val2 = vm.getRegister(it.oper2);
		if (val1 < val2) {
			vm.pc = vm.getTextLabel(it.oper3);
			vm.setRegister("$pc", vm.pc);
			//break;
		}
		else {
			vm.pc++;
			vm.setRegister("$pc", vm.pc);
		}
	}
	else if (it.opcode == "sub") {
		std::string resultreg = it.oper1;
		std::string subreg = it.oper2;
		uint32_t val2 = vm.getRegister(subreg);
		if (vm.isRegister(it.oper3)) {
			uint32_t val3 = vm.getRegister(it.oper3);
			int64_t sub = (int64_t)val2 - (int64_t)val3;
			//if (sum < std::numeric_limits<uint32_t>::max()) {
			vm.setRegister(resultreg, sub);
			vm.pc++;
			vm.setRegister("$pc", vm.pc);
		}
		else if (vm.isConstantStr(it.oper3)) {
			if (vm.constantExists(it.oper3)) {
				int val3 = vm.getConstant(it.oper3);
				int64_t sub = (int64_t)val2 - (int64_t)val3;
				vm.setRegister(resultreg, sub);
				vm.pc++;
				vm.setRegister("$pc", vm.pc);
			}
		}
		else {
			simulated = false;
			//break;
		}
	}
	else if (it.opcode == "subu") {
		std::string resultreg = it.oper1;
		std::string subreg = it.oper2;
		int val2 = vm.getRegister(subreg);
		if (vm.isRegister(it.oper3)) {
			int val3 = vm.getRegister(it.oper3);
			int sub = val2 - val3;
			vm.setRegister(resultreg, sub);
			vm.pc++;
			vm.setRegister("$pc", vm.pc);
		}
		else if (vm.isConstantStr(it.oper3)) {
			if (vm.constantExists(it.oper3)) {
				int val3 = vm.getConstant(it.oper3);
				int sub = val2 - val3;
				vm.setRegister(resultreg, sub);
				vm.pc++;
				vm.setRegister("$pc", vm.pc);
			}
		}
		else {
			simulated = false;
			//break;
		}
	}
	else if (it.opcode == "div") {
		int val1 = vm.getRegister(it.oper1);
		int val2 = vm.getRegister(it.oper2);
		int32_t quotient = int32_t(val1) / int32_t(val2);
		int32_t remainder = int32_t(val1) % int32_t(val2);
		vm.setRegister("$hi", remainder);
		vm.setRegister("$lo", quotient);
		vm.pc++;
		vm.setRegister("$pc", vm.pc);
	}
	else if (it.opcode == "and") {
		std::string resultreg = it.oper1;
		int val1 = vm.getRegister(it.oper2);
		if (vm.isRegister(it.oper3)) {
			int val2 = vm.getRegister(it.oper3);
			int andVal = val1 & val2;
			vm.setRegister(resultreg, andVal);
			vm.pc++;
			vm.setRegister("$pc", vm.pc);
		}
		else if (vm.isConstantStr(it.oper3)) {
			int val2 = vm.getConstant(it.oper3);
			int andVal = val1 & val2;
			vm.setRegister(resultreg, andVal);
			vm.pc++;
			vm.setRegister("$pc", vm.pc);
		}
		else {
			simulated = false;
			//break;
		}
	}
	else if (it.opcode == "nor") {
		std::string resultreg = it.oper1;
		int val1 = vm.getRegister(it.oper2);
		if (vm.isRegister(it.oper3)) {
			int val2 = vm.getRegister(it.oper3);
			int norVal = ~(val1 | val2);
			vm.setRegister(resultreg, norVal);
			vm.pc++;
			vm.setRegister("$pc", vm.pc);
		}
		else if (vm.isConstantStr(it.oper3)) {
			int val2 = vm.getConstant(it.oper3);
			int norVal = ~(val1 | val2);
			vm.setRegister(resultreg, norVal);
			vm.pc++;
			vm.setRegister("$pc", vm.pc);
		}
		else {
			simulated = false;
			//break;
		}
	}
	else if (it.opcode == "or") {
		std::string resultreg = it.oper1;
		int val1 = vm.getRegister(it.oper2);
		if (vm.isRegister(it.oper3)) {
			int val2 = vm.getRegister(it.oper3);
			int orVal = val1 | val2;
			vm.setRegister(resultreg, orVal);
			vm.pc++;
			vm.setRegister("$pc", vm.pc);
		}
		else if (vm.isConstantStr(it.oper3)) {
			int val2 = vm.getConstant(it.oper3);
			int orVal = val1 | val2;
			vm.setRegister(resultreg, orVal);
			vm.pc++;
			vm.setRegister("$pc", vm.pc);
		}
		else {
			simulated = false;
			//break;
		}
	}
	else if (it.opcode == "xor") {
		std::string resultreg = it.oper1;
		int val1 = vm.getRegister(it.oper2);
		if (vm.isRegister(it.oper3)) {
			int val2 = vm.getRegister(it.oper3);
			int xorVal = val1 ^ val2;
			vm.setRegister(resultreg, xorVal);
			vm.pc++;
			vm.setRegister("$pc", vm.pc);
		}
		else if (vm.isConstantStr(it.oper3)) {
			int val2 = vm.getConstant(it.oper3);
			int xorVal = val1 ^ val2;
			vm.setRegister(resultreg, xorVal);
			vm.pc++;
			vm.setRegister("$pc", vm.pc);
		}
		else {
			simulated = false;
			//break;
		}
	}
	else if (it.opcode == "not") {
		std::string resultreg = it.oper1;
		if (vm.isRegister(it.oper2)) {
			int val = vm.getRegister(it.oper2);
			int notVal = ~val;
			vm.setRegister(resultreg, notVal);
			vm.pc++;
			vm.setRegister("$pc", vm.pc);
		}
		else if (vm.isConstantStr(it.oper2)) {
			int val = vm.getConstant(it.oper2);
			int notVal = ~val;
			vm.setRegister(resultreg, notVal);
			vm.pc++;
			vm.setRegister("$pc", vm.pc);
		}
		else {
			simulated = false;
			//break;
		}
	}
	else {
		simulated = false;
		//break;
	}
	//it++;
//}
/*}
else {
	simulated = false;
}*/
	std::pair<bool, VirtualMachine> final;
	final.first = simulated;
	final.second = vm;
	return final;
}

bool VirtualMachine::addWHBToMemory(std::string value, int bytes) {
	long int val = stoi(value);
	//unsigned char bits = bytes * 8;
	if (nextOpenMem + bytes < 1024) {
		if (bytes == 1) {
			//if (val <= 255 && val >= 0) {
			memArray[nextOpenMem] = (int)((val & 0xFF));
			nextOpenMem++;
			//}
		}
		else if (bytes == 2) {
			//if (val <= 65535 && val >= 0) {
			memArray[nextOpenMem] = (int)((val & 0xFF));
			memArray[nextOpenMem + 1] = (int)((val >> 8) & 0XFF);
			nextOpenMem += 2;
			//}
		}
		else if (bytes == 4) {
			//if (val <= 4294967295 && val >= 0) {
			memArray[nextOpenMem] = (int)((val & 0xFF));
			memArray[nextOpenMem + 1] = (int)((val >> 8) & 0XFF);
			memArray[nextOpenMem + 2] = (int)((val >> 16) & 0xFF);
			memArray[nextOpenMem + 3] = (int)((val >> 24) & 0xFF);
			nextOpenMem += 4;
			//}
		}
		else {
			return false;
		}
		return true;
	}
	return false;
}

void VirtualMachine::replaceMemoryWord(std::string value, int ptr) {
	long int val = stoi(value);
	//if (val <= 4294967295 && val >= 0) {
	memArray[ptr] = (int)((val & 0xFF));
	memArray[ptr + 1] = (int)((val >> 8) & 0XFF);
	memArray[ptr + 2] = (int)((val >> 16) & 0xFF);
	memArray[ptr + 3] = (int)((val >> 24) & 0xFF);
	//}
}

bool VirtualMachine::addSpaceToMemory(int bytes) {
	if (nextOpenMem + bytes <= 1024 && bytes <= 1024) {
		for (int i = 0; i < bytes; i++) {
			memArray[nextOpenMem + i] = 0;
		}
		nextOpenMem += bytes;
		return true;
	}
	return false;
}

bool VirtualMachine::addStringToMemory(std::string asc_type, std::string the_str) {
	if (asc_type == ".ascii") {
		if (nextOpenMem + the_str.length() < 1024) {
			for (std::size_t i = 0; i < the_str.length(); i++) {
				memArray[nextOpenMem + i] = int(the_str[i]);
			}
			nextOpenMem += the_str.length();
			return true;
		}
	}
	else if (asc_type == ".asciiz") {
		if (nextOpenMem + the_str.length() + 1 < 1024) {
			for (std::size_t i = 0; i < the_str.length(); i++) {
				memArray[nextOpenMem + i] = int(the_str[i]);
			}
			nextOpenMem += the_str.length();
			memArray[nextOpenMem] = 0;
			nextOpenMem++;
			return true;
		}
	}
	else
		return false;
	return false;
}

void VirtualMachine::addConstant(std::string constName, std::string intString) {
	int numForm = stoi(intString);
	constants.insert({ constName, numForm });
}

void VirtualMachine::addDataLabel(std::string label, std::pair <std::string, int> pointMem) {
	if (label[label.length() - 1] == ':')
		label.pop_back();
	dataLabels.insert({ label, pointMem });
}

void VirtualMachine::addTextLabel(std::string label, int pointer) {
	if (label[label.length() - 1] == ':')
		label.pop_back();
	textLabels.insert({ label, pointer });
}

int VirtualMachine::getConstant(std::string constName) {
	return constants.at(constName);
}

std::pair <std::string, int> VirtualMachine::getDataLabel(std::string labelName) {
	if (labelName[labelName.length() - 1] == ':')
		labelName.pop_back();
	return dataLabels.at(labelName);
}

int VirtualMachine::getTextLabel(std::string labelName) {
	if (labelName[labelName.length() - 1] == ':')
		labelName.pop_back();
	return textLabels.at(labelName);
}

bool VirtualMachine::constantExists(std::string constName) {
	return (!(constants.find(constName) == constants.end()));
}

bool VirtualMachine::dataLabelExists(std::string labelName) {
	if (labelName[labelName.length() - 1] == ':')
		labelName.pop_back();
	return (!(dataLabels.find(labelName) == dataLabels.end()));
}

bool VirtualMachine::textLabelExists(std::string labelName) {
	if (labelName[labelName.length() - 1] == ':')
		labelName.pop_back();
	return (!(textLabels.find(labelName) == textLabels.end()));
}



int VirtualMachine::getMemRefVal(int offset, int ptr) {
	int backToInt = ((memArray[ptr + offset + 3] << 24)
		+ (memArray[ptr + offset + 2] << 16)
		+ (memArray[ptr + offset + 1] << 8)
		+ (memArray[ptr + offset]));
	return backToInt;
}



void VirtualMachine::setRegister(std::string oper, int64_t val) {
	if (oper == "$zero") { registersArr[0] = val; }
	else if (oper == "$at") { registersArr[1] = val; }
	else if (oper == "$v0") { registersArr[2] = val; }
	else if (oper == "$v1") { registersArr[3] = val; }
	else if (oper == "$a0") { registersArr[4] = val; }
	else if (oper == "$a1") { registersArr[5] = val; }
	else if (oper == "$a2") { registersArr[6] = val; }
	else if (oper == "$a3") { registersArr[7] = val; }
	else if (oper == "$t0") { registersArr[8] = val; }
	else if (oper == "$t1") { registersArr[9] = val; }
	else if (oper == "$t2") { registersArr[10] = val; }
	else if (oper == "$t3") { registersArr[11] = val; }
	else if (oper == "$t4") { registersArr[12] = val; }
	else if (oper == "$t5") { registersArr[13] = val; }
	else if (oper == "$t6") { registersArr[14] = val; }
	else if (oper == "$t7") { registersArr[15] = val; }
	else if (oper == "$s0") { registersArr[16] = val; }
	else if (oper == "$s1") { registersArr[17] = val; }
	else if (oper == "$s2") { registersArr[18] = val; }
	else if (oper == "$s3") { registersArr[19] = val; }
	else if (oper == "$s4") { registersArr[20] = val; }
	else if (oper == "$s5") { registersArr[21] = val; }
	else if (oper == "$s6") { registersArr[22] = val; }
	else if (oper == "$s7") { registersArr[23] = val; }
	else if (oper == "$t8") { registersArr[24] = val; }
	else if (oper == "$t9") { registersArr[25] = val; }
	else if (oper == "$k0") { registersArr[26] = val; }
	else if (oper == "$k1") { registersArr[27] = val; }
	else if (oper == "$gp") { registersArr[28] = val; }
	else if (oper == "$sp") { registersArr[29] = val; }
	else if (oper == "$fp") { registersArr[30] = val; }
	else if (oper == "$ra") { registersArr[31] = val; }
	else if (oper == "$pc") { registersArr[32] = val; }
	else if (oper == "$hi") { registersArr[33] = val; }
	else if (oper == "$lo") { registersArr[34] = val; }
	else return;
}

int VirtualMachine::getRegister(std::string oper) {
	if (oper == "$zero") { return registersArr[0]; }
	else if (oper == "$at") { return registersArr[1]; }
	else if (oper == "$v0") { return registersArr[2]; }
	else if (oper == "$v1") { return registersArr[3]; }
	else if (oper == "$a0") { return registersArr[4]; }
	else if (oper == "$a1") { return registersArr[5]; }
	else if (oper == "$a2") { return registersArr[6]; }
	else if (oper == "$a3") { return registersArr[7]; }
	else if (oper == "$t0") { return registersArr[8]; }
	else if (oper == "$t1") { return registersArr[9]; }
	else if (oper == "$t2") { return registersArr[10]; }
	else if (oper == "$t3") { return registersArr[11]; }
	else if (oper == "$t4") { return registersArr[12]; }
	else if (oper == "$t5") { return registersArr[13]; }
	else if (oper == "$t6") { return registersArr[14]; }
	else if (oper == "$t7") { return registersArr[15]; }
	else if (oper == "$s0") { return registersArr[16]; }
	else if (oper == "$s1") { return registersArr[17]; }
	else if (oper == "$s2") { return registersArr[18]; }
	else if (oper == "$s3") { return registersArr[19]; }
	else if (oper == "$s4") { return registersArr[20]; }
	else if (oper == "$s5") { return registersArr[21]; }
	else if (oper == "$s6") { return registersArr[22]; }
	else if (oper == "$s7") { return registersArr[23]; }
	else if (oper == "$t8") { return registersArr[24]; }
	else if (oper == "$t9") { return registersArr[25]; }
	else if (oper == "$k0") { return registersArr[26]; }
	else if (oper == "$k1") { return registersArr[27]; }
	else if (oper == "$gp") { return registersArr[28]; }
	else if (oper == "$sp") { return registersArr[29]; }
	else if (oper == "$fp") { return registersArr[30]; }
	else if (oper == "$ra") { return registersArr[31]; }
	else if (oper == "$pc") { return registersArr[32]; }
	else if (oper == "$hi") { return registersArr[33]; }
	else if (oper == "$lo") { return registersArr[34]; }
	else
		return -1;
}

bool VirtualMachine::isInteger(std::string value) {
	bool is = false;
	if (value[0] == '-' || value[0] == '+' || isdigit(value[0])) {
		for (std::size_t i = 1; i < value.length(); i++) {
			if (!isdigit(value[i]))
				return false;
		}
		is = true;
	}
	return is;
}

bool VirtualMachine::isConstantStr(std::string value) {
	bool is = false;
	if (isAlpha(value[0])) {
		for (std::size_t i = 1; i < value.length(); i++) {
			if (!isAlpha(value[i]) && !isdigit(value[i]))
				return false;
		}
		is = true;
	}
	return is;
}

bool VirtualMachine::isAlpha(char c) {
	return ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == '_');
}

bool VirtualMachine::isRegister(std::string regName) {
	if (regName == "$zero" || regName == "$at" || regName == "$v0" || regName == "$v1" || regName == "$a0" || regName == "$a1"
		|| regName == "$a2" || regName == "$a3" || regName == "$a4" || regName == "$a5" || regName == "$t0" || regName == "$t1"
		|| regName == "$t2" || regName == "$t3" || regName == "$t4" || regName == "$t5" || regName == "$t6" || regName == "$t7"
		|| regName == "$s0" || regName == "$s1" || regName == "$s2" || regName == "$s3" || regName == "$s4" || regName == "$s5"
		|| regName == "$s6" || regName == "$s7" || regName == "$t8" || regName == "$t9" || regName == "$k0" || regName == "$k1"
		|| regName == "$gp" || regName == "$sp" || regName == "$fp" || regName == "$ra" || regName == "$pc" || regName == "$hi" || regName == "$lo") {
		return true;
	}
	return false;
}